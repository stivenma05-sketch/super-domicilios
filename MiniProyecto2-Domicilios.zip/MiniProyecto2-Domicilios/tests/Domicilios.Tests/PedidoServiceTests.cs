using Domicilios.Core.Entidades;
using Domicilios.Core.Estructuras;
using Domicilios.Core.Servicios;

namespace Domicilios.Tests;

public class PedidoServiceTests
{
    private readonly FakeProductoRepositorio _productos = new();
    private readonly FakePedidoRepositorio _pedidos = new();
    private readonly FakeUnidadDeTrabajo _unidad = new();
    private readonly PedidoService _servicio;

    public PedidoServiceTests()
    {
        _productos.Productos.Add(new Producto { Id = 1, Nombre = "Arroz", Precio = 10_000m, Stock = 10, Unidad = "und" });
        _productos.Productos.Add(new Producto { Id = 2, Nombre = "Leche", Precio = 4_000m, Stock = 5, Unidad = "und" });
        _servicio = new PedidoService(_productos, _pedidos, _unidad, new CatalogoCupones());
    }

    private CarritoCompras CarritoCon(int productoId, int cantidad)
    {
        var carrito = new CarritoCompras();
        carrito.Agregar(_productos.Productos.First(p => p.Id == productoId), cantidad);
        return carrito;
    }

    private async Task<Pedido> CrearPedidoValidoAsync(string? cupon = null)
    {
        var resultado = await _servicio.CrearPedidoAsync("u1", "Laura", CarritoCon(1, 3), "Calle 1 # 2-3", ZonaEntrega.Centro, cupon);
        Assert.True(resultado.Exito, resultado.Error);
        return resultado.Valor!;
    }

    [Fact]
    public async Task CrearPedido_CalculaTotalesYDescuentaInventario()
    {
        var pedido = await CrearPedidoValidoAsync("BIENVENIDO10");

        Assert.Equal(30_000m, pedido.Subtotal);
        Assert.Equal(3_000m, pedido.Descuento);
        Assert.Equal(4_000m, pedido.CostoDomicilio);
        Assert.Equal(31_000m, pedido.Total);
        Assert.Equal(7, _productos.Productos[0].Stock);
        Assert.Equal(EstadoPedido.Pendiente, pedido.Estado);
        Assert.Single(pedido.Historial);
        Assert.Equal(1, _unidad.Guardados);
    }

    [Fact]
    public async Task CrearPedido_UsaElPrecioDeLaBaseDeDatosNoElDelCarrito()
    {
        var carrito = CarritoCon(1, 1);
        carrito[1].PrecioUnitario = 1m;   // alguien manipuló el precio

        var resultado = await _servicio.CrearPedidoAsync("u1", "Laura", carrito, "Calle 1", ZonaEntrega.Centro, null);

        Assert.Equal(10_000m, resultado.Valor!.Subtotal);
    }

    [Fact]
    public async Task CrearPedido_FallaSinStockYNoModificaInventario()
    {
        var carrito = CarritoCon(2, 5);
        _productos.Productos[1].Stock = 2;   // otro cliente compró antes

        var resultado = await _servicio.CrearPedidoAsync("u1", "Laura", carrito, "Calle 1", ZonaEntrega.Centro, null);

        Assert.False(resultado.Exito);
        Assert.Equal(2, _productos.Productos[1].Stock);
        Assert.Empty(_pedidos.Pedidos);
    }

    [Fact]
    public async Task CrearPedido_ValidaDireccionCarritoYCupon()
    {
        Assert.False((await _servicio.CrearPedidoAsync("u1", "L", CarritoCon(1, 1), " ", ZonaEntrega.Sur, null)).Exito);
        Assert.False((await _servicio.CrearPedidoAsync("u1", "L", new CarritoCompras(), "Calle 1", ZonaEntrega.Sur, null)).Exito);
        Assert.False((await _servicio.CrearPedidoAsync("u1", "L", CarritoCon(1, 1), "Calle 1", ZonaEntrega.Sur, "FALSO")).Exito);
    }

    [Fact]
    public async Task FlujoCompleto_PendienteAEntregadoDisparaEventos()
    {
        var pedido = await CrearPedidoValidoAsync();
        var eventos = new List<CambioEstadoEventArgs>();
        _servicio.EstadoCambiado += (_, e) => eventos.Add(e);

        Assert.True((await _servicio.CambiarEstadoAsync(pedido.Id, EstadoPedido.EnPreparacion, "Admin")).Exito);
        Assert.True((await _servicio.TomarPedidoAsync(pedido.Id, "r1", "Carlos")).Exito);
        Assert.True((await _servicio.CambiarEstadoAsync(pedido.Id, EstadoPedido.Entregado, "Carlos")).Exito);

        Assert.Equal(EstadoPedido.Entregado, pedido.Estado);
        Assert.Equal("Carlos", pedido.RepartidorNombre);
        Assert.Equal(3, eventos.Count);
        Assert.Equal(4, pedido.Historial.Count);
    }

    [Fact]
    public async Task CambiarEstado_RechazaTransicionesInvalidas()
    {
        var pedido = await CrearPedidoValidoAsync();

        var resultado = await _servicio.CambiarEstadoAsync(pedido.Id, EstadoPedido.Entregado, "Admin");

        Assert.False(resultado.Exito);
        Assert.Equal(EstadoPedido.Pendiente, pedido.Estado);
    }

    [Fact]
    public async Task Cancelar_DevuelveElInventario()
    {
        var pedido = await CrearPedidoValidoAsync();
        Assert.Equal(7, _productos.Productos[0].Stock);

        await _servicio.CambiarEstadoAsync(pedido.Id, EstadoPedido.Cancelado, "Admin");

        Assert.Equal(10, _productos.Productos[0].Stock);
        Assert.Equal(EstadoPedido.Cancelado, pedido.Estado);
    }

    [Fact]
    public async Task TomarPedido_SoloSiEstaEnPreparacion()
    {
        var pedido = await CrearPedidoValidoAsync();

        Assert.False((await _servicio.TomarPedidoAsync(pedido.Id, "r1", "Carlos")).Exito);
    }

    [Fact]
    public async Task Deshacer_RevierteElUltimoCambioYLiberaAlRepartidor()
    {
        var pedido = await CrearPedidoValidoAsync();
        await _servicio.CambiarEstadoAsync(pedido.Id, EstadoPedido.EnPreparacion, "Admin");
        await _servicio.TomarPedidoAsync(pedido.Id, "r1", "Carlos");

        var resultado = await _servicio.DeshacerUltimoCambioAsync(pedido.Id);

        Assert.True(resultado.Exito);
        Assert.Equal(EstadoPedido.EnPreparacion, pedido.Estado);
        Assert.Null(pedido.RepartidorId);
        Assert.Equal(2, pedido.Historial.Count);
    }

    [Fact]
    public async Task Deshacer_NoPermiteRevertirPedidosFinalizados()
    {
        var pedido = await CrearPedidoValidoAsync();
        await _servicio.CambiarEstadoAsync(pedido.Id, EstadoPedido.Cancelado, "Admin");

        Assert.False((await _servicio.DeshacerUltimoCambioAsync(pedido.Id)).Exito);
    }
}
