using Domicilios.Core.Entidades;
using Domicilios.Core.Servicios;

namespace Domicilios.Tests;

public class ReporteServiceTests
{
    private static Pedido NuevoPedido(ZonaEntrega zona, EstadoPedido estado, decimal total, params (string Nombre, int Cantidad, decimal Precio)[] items)
    {
        var pedido = new Pedido { Zona = zona, Estado = estado, Total = total, FechaCreacion = new DateTime(2026, 11, 17, 10, 0, 0) };
        foreach (var (nombre, cantidad, precio) in items)
            pedido.Items.Add(new PedidoItem { NombreProducto = nombre, Cantidad = cantidad, PrecioUnitario = precio });
        return pedido;
    }

    private static List<Pedido> Datos() => new()
    {
        NuevoPedido(ZonaEntrega.Norte, EstadoPedido.Entregado, 30_000m, ("Arroz", 2, 10_000m), ("Leche", 2, 5_000m)),
        NuevoPedido(ZonaEntrega.Sur, EstadoPedido.Pendiente, 10_000m, ("Arroz", 1, 10_000m)),
        NuevoPedido(ZonaEntrega.Norte, EstadoPedido.Cancelado, 99_000m, ("Arroz", 9, 10_000m)),
    };

    [Fact]
    public void Resumen_IgnoraPedidosCancelados()
    {
        var resumen = ReporteService.Resumen(Datos());

        Assert.Equal(3, resumen.TotalPedidos);
        Assert.Equal(1, resumen.Entregados);
        Assert.Equal(1, resumen.Cancelados);
        Assert.Equal(40_000m, resumen.Ingresos);
        Assert.Equal(20_000m, resumen.TicketPromedio);
    }

    [Fact]
    public void VentasPorZona_AgrupaYMantieneOrden()
    {
        var zonas = ReporteService.VentasPorZona(Datos());

        Assert.Equal(new[] { ZonaEntrega.Norte, ZonaEntrega.Sur }, zonas.Keys);
        Assert.Equal(30_000m, zonas[ZonaEntrega.Norte].Total);
    }

    [Fact]
    public void TopProductos_OrdenaPorUnidadesVendidas()
    {
        var top = ReporteService.TopProductos(Datos(), 2);

        Assert.Equal("Arroz", top[0].Nombre);
        Assert.Equal(3, top[0].Unidades);
        Assert.Equal("Leche", top[1].Nombre);
    }

    [Fact]
    public void VentasPorDia_AgrupaPorFecha()
    {
        var dias = ReporteService.VentasPorDia(Datos());

        Assert.Single(dias);
        Assert.Equal(2, dias[0].Pedidos);
    }
}
