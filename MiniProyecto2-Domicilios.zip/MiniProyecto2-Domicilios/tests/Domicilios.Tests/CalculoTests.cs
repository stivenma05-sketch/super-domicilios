using Domicilios.Core.Descuentos;
using Domicilios.Core.Entidades;
using Domicilios.Core.Estructuras;
using Domicilios.Core.Servicios;

namespace Domicilios.Tests;

public class CalculoTests
{
    [Fact]
    public void Dinero_SobrecargaOperadoresYFormato()
    {
        Dinero total = new Dinero(1_000m) + new Dinero(500m) * 2;

        Assert.Equal(2_000m, total.Valor);
        Assert.Equal("$12.500", new Dinero(12_500m).ToString());
    }

    [Fact]
    public void Domicilio_SeCobraPorZonaYEsGratisDesdeElUmbral()
    {
        var pequena = CalculadoraPedido.Calcular(new Dinero(50_000m), ZonaEntrega.Norte, new SinDescuento());
        Assert.Equal(6_000m, pequena.Domicilio.Valor);
        Assert.Equal(56_000m, pequena.Total.Valor);

        var grande = CalculadoraPedido.Calcular(new Dinero(130_000m), ZonaEntrega.Norte, new SinDescuento());
        Assert.Equal(0m, grande.Domicilio.Valor);
    }

    [Fact]
    public void DescuentoPorcentaje_AplicaElPorcentaje()
    {
        var resumen = CalculadoraPedido.Calcular(new Dinero(100_000m), ZonaEntrega.Centro, new DescuentoPorcentaje(10));

        Assert.Equal(10_000m, resumen.Descuento.Valor);
        Assert.Equal(94_000m, resumen.Total.Valor);   // 90.000 + 4.000 de domicilio
    }

    [Fact]
    public void DescuentoMontoFijo_RequiereCompraMinima()
    {
        var descuento = new DescuentoMontoFijo(20_000m, 150_000m);

        Assert.Equal(0m, descuento.Calcular(new Dinero(100_000m)).Valor);
        Assert.Equal(20_000m, descuento.Calcular(new Dinero(160_000m)).Valor);
    }

    [Fact]
    public void Cupones_IgnoranMayusculasYDevuelvenSinDescuentoSiNoExisten()
    {
        var cupones = new CatalogoCupones();

        Assert.True(cupones.Existe("bienvenido10"));
        Assert.IsType<DescuentoPorcentaje>(cupones.Obtener("BIENVENIDO10"));
        Assert.IsType<SinDescuento>(cupones.Obtener("NOEXISTE"));
    }

    [Fact]
    public void DescuentoPorcentaje_RechazaPorcentajesInvalidos()
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => new DescuentoPorcentaje(0));
        Assert.Throws<ArgumentOutOfRangeException>(() => new DescuentoPorcentaje(150));
    }

    [Fact]
    public void ComparadorEstructuras_DevuelveResultadosParaCadaEstructura()
    {
        var resultados = ComparadorEstructuras.Ejecutar(elementos: 2_000, busquedas: 200);

        Assert.Equal(6, resultados.Count);
        Assert.All(resultados, r => Assert.True(r.Milisegundos >= 0));
    }
}
