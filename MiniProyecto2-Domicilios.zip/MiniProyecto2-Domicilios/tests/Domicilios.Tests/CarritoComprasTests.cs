using Domicilios.Core.Entidades;
using Domicilios.Core.Estructuras;

namespace Domicilios.Tests;

public class CarritoComprasTests
{
    private static Producto Arroz(int stock = 10) =>
        new() { Id = 1, Nombre = "Arroz", Precio = 5_000m, Stock = stock, Unidad = "und" };

    [Fact]
    public void Agregar_SumaCantidadSiElProductoYaExiste()
    {
        var carrito = new CarritoCompras();
        carrito.Agregar(Arroz(), 2);
        carrito.Agregar(Arroz(), 3);

        Assert.Equal(1, carrito.Cantidad);          // una sola línea
        Assert.Equal(5, carrito[1].Cantidad);        // indexador
        Assert.Equal(25_000m, carrito.Subtotal.Valor);
    }

    [Fact]
    public void Agregar_FallaSiSuperaElStock()
    {
        var carrito = new CarritoCompras();
        var resultado = carrito.Agregar(Arroz(stock: 3), 4);

        Assert.False(resultado.Exito);
        Assert.Equal(0, carrito.Cantidad);
    }

    [Fact]
    public void Agregar_FallaConCantidadInvalidaOProductoInactivo()
    {
        var carrito = new CarritoCompras();
        Assert.False(carrito.Agregar(Arroz(), 0).Exito);

        var inactivo = Arroz();
        inactivo.Activo = false;
        Assert.False(carrito.Agregar(inactivo, 1).Exito);
    }

    [Fact]
    public void Quitar_EliminaLaLinea()
    {
        var carrito = new CarritoCompras();
        carrito.Agregar(Arroz(), 1);

        Assert.True(carrito.Quitar(1));
        Assert.False(carrito.Contiene(1));
        Assert.False(carrito.Quitar(1));
    }

    [Fact]
    public void Enumerar_RecorreTodosLosItems()
    {
        var carrito = new CarritoCompras();
        carrito.Agregar(Arroz(), 1);
        carrito.Agregar(new Producto { Id = 2, Nombre = "Leche", Precio = 4_000m, Stock = 5 }, 2);

        Assert.Equal(new[] { "Arroz", "Leche" }, carrito.Select(i => i.Nombre).OrderBy(n => n));
        Assert.Equal(3, carrito.TotalUnidades);
    }
}
