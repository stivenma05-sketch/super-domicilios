using Domicilios.Core.Contratos;
using Domicilios.Core.Entidades;

namespace Domicilios.Tests;

/// <summary>Repositorios en memoria para probar la lógica de negocio sin base de datos.</summary>
public class FakeProductoRepositorio : IProductoRepositorio
{
    public List<Producto> Productos { get; } = new();

    public Task<List<Producto>> ListarAsync(int? categoriaId = null, string? busqueda = null, bool soloActivos = true) =>
        Task.FromResult(Productos
            .Where(p => !soloActivos || p.Activo)
            .Where(p => categoriaId is null || p.CategoriaId == categoriaId)
            .Where(p => string.IsNullOrWhiteSpace(busqueda) || p.Nombre.Contains(busqueda, StringComparison.OrdinalIgnoreCase))
            .ToList());

    public Task<Producto?> ObtenerAsync(int id) => Task.FromResult(Productos.FirstOrDefault(p => p.Id == id));

    public Task<List<Categoria>> ListarCategoriasAsync() => Task.FromResult(new List<Categoria>());

    public Task AgregarAsync(Producto producto)
    {
        Productos.Add(producto);
        return Task.CompletedTask;
    }

    public Task ActualizarAsync(Producto producto) => Task.CompletedTask;
}

public class FakePedidoRepositorio : IPedidoRepositorio
{
    private int _siguienteId = 1;
    public List<Pedido> Pedidos { get; } = new();

    public Task<Pedido?> ObtenerAsync(int id) => Task.FromResult(Pedidos.FirstOrDefault(p => p.Id == id));

    public Task<List<Pedido>> ListarAsync(string? clienteId = null, string? repartidorId = null, EstadoPedido? estado = null) =>
        Task.FromResult(Pedidos
            .Where(p => clienteId is null || p.ClienteId == clienteId)
            .Where(p => repartidorId is null || p.RepartidorId == repartidorId)
            .Where(p => estado is null || p.Estado == estado)
            .ToList());

    public Task AgregarAsync(Pedido pedido)
    {
        pedido.Id = _siguienteId++;
        Pedidos.Add(pedido);
        return Task.CompletedTask;
    }
}

public class FakeUnidadDeTrabajo : IUnidadDeTrabajo
{
    public int Guardados { get; private set; }

    public Task<int> GuardarCambiosAsync()
    {
        Guardados++;
        return Task.FromResult(1);
    }
}
