# Justificación de estructuras de datos

Para cada estructura: **qué problema resuelve**, **por qué esa y no otra** y **dónde está en el código**. La página *Estructuras* (rol Admin, web) y la pestaña *Estructuras de datos* (escritorio) ejecutan `ComparadorEstructuras` y muestran los tiempos reales.

## Resumen

| Estructura | Uso en el proyecto | Operación clave | Complejidad | Alternativa descartada |
|---|---|---|---|---|
| `Dictionary<int, ItemCarrito>` | Carrito de compras (`CarritoCompras`) | Buscar / actualizar línea por id de producto | O(1) | `List<ItemCarrito>` (O(n) y permite duplicados) |
| `Dictionary<ZonaEntrega, decimal>` | Tarifas de domicilio (`TarifaDomicilio`) | Tarifa por zona | O(1) | `switch` repetido en varios lugares |
| `Dictionary<string, Descuento>` (sin distinguir mayúsculas) | Cupones (`CatalogoCupones`) | Validar un código | O(1) | `List<Cupon>` con búsqueda lineal |
| `Dictionary<EstadoPedido, HashSet<EstadoPedido>>` | Máquina de estados (`PedidoService`) | ¿Es válida la transición A → B? | O(1) | `if` anidados difíciles de mantener |
| `HashSet<EstadoPedido>` | Estados permitidos desde cada estado | Pertenencia sin duplicados | O(1) | `List<EstadoPedido>` |
| `Stack<CambioEstado>` | Deshacer el último cambio de estado | Sacar el más reciente (LIFO) | O(1) | `List` con índices manuales |
| `SortedDictionary<ZonaEntrega, VentaZona>` | Reporte de ventas por zona | Recorrer zonas siempre en el mismo orden | O(log n) | `Dictionary` (orden no garantizado) |
| `Queue<T>` | Cola de despacho FIFO (comparativa) | Atender el pedido más antiguo | O(1) | `List.RemoveAt(0)` (O(n)) |
| `List<T>` | Resultados de consultas, ítems del pedido | Recorrer y agregar al final | O(1) amortizado | Arreglo (tamaño fijo) |

## Decisiones explicadas

### 1. Carrito: `Dictionary` y no `List`
Un producto debe aparecer **una sola vez** en el carrito; si el cliente lo agrega de nuevo se suma la cantidad. Con `Dictionary<int, ItemCarrito>` la clave (id del producto) garantiza unicidad y el acceso es O(1). Con una `List` habría que recorrerla para ver si el producto ya existe (O(n)) y se podrían crear duplicados por error. Además expone el indexador `carrito[productoId]`.

### 2. Cupones: `Dictionary` con `StringComparer.OrdinalIgnoreCase`
El cliente escribe `bienvenido10`, `Bienvenido10` o `BIENVENIDO10`. El comparador del diccionario resuelve eso sin transformar cadenas a mano, y cada cupón guarda su propia **estrategia** de descuento (`Descuento` abstracta).

### 3. Estados del pedido: `Dictionary` de `HashSet`
La regla "de Pendiente solo se puede ir a En preparación o Cancelado" es **datos**, no código. Agregar un estado nuevo es agregar una entrada, sin tocar la lógica. `HashSet` evita transiciones repetidas y valida con `Contains` en O(1).

### 4. Deshacer: `Stack`
Revertir el último cambio es un caso típico LIFO: el estado más reciente es el primero en salir (`Pop`) y el anterior queda visible con `Peek`. Se reconstruye la pila desde el historial persistido en la base de datos.

### 5. Reportes por zona: `SortedDictionary`
Los reportes deben mostrar siempre las zonas en el mismo orden. `SortedDictionary` lo garantiza por clave; `Dictionary` no.

### 6. Despacho FIFO: `Queue`
Los pedidos se atienden por orden de llegada. `Queue.Dequeue()` es O(1); `List.RemoveAt(0)` desplaza todos los elementos (O(n)), lo que se nota al crecer el volumen. La comparativa lo demuestra.

## Ejemplo comparativo (`ComparadorEstructuras`)

Mismo trabajo, 20 000 elementos:

* **Buscar por id** (2 000 búsquedas): `List.Contains` (O(n)) vs `HashSet.Contains` / `Dictionary.TryGetValue` (O(1)) vs `SortedDictionary.TryGetValue` (O(log n)).
* **Despachar pedidos FIFO**: `List.RemoveAt(0)` vs `Queue.Dequeue`.

Resultado esperado (órdenes de magnitud según la complejidad; no son mediciones exactas, ejecuta la comparativa para tus números reales):

| Operación | Estructura | Complejidad | Tiempo aprox. |
|---|---|---|---|
| Buscar por id | `List<T>.Contains` | O(n) | decenas de ms |
| Buscar por id | `HashSet<T>.Contains` | O(1) | < 1 ms |
| Buscar por id | `Dictionary<K,V>` | O(1) | < 1 ms |
| Buscar por id | `SortedDictionary<K,V>` | O(log n) | ~ 1 ms |
| Despachar FIFO | `List<T>.RemoveAt(0)` | O(n) por extracción | decenas de ms |
| Despachar FIFO | `Queue<T>.Dequeue` | O(1) por extracción | < 1 ms |

> Ten presente que estos valores son orientativos: antes de la sustentación ejecuta la comparativa en tu propio equipo y copia los números reales a las diapositivas.

## Por qué la base de datos no usa estas estructuras

Las estructuras en memoria resuelven problemas **de la lógica** (carrito, reglas, reportes). Lo que debe persistir (productos, pedidos, usuarios) vive en tablas de SQLite administradas con Entity Framework Core, que a su vez usa índices (`HasIndex`) para consultas rápidas por cliente y por estado.
