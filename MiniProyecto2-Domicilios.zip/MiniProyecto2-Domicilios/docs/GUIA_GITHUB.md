# Subir el proyecto a GitHub

El repositorio git local ya está creado con el primer commit. Falta crear el repositorio remoto y hacer `push`.

## Opción A — con GitHub CLI (`gh`)

```bash
cd MiniProyecto2-Domicilios
gh auth login
gh repo create super-domicilios --public --source=. --remote=origin --push
```

## Opción B — desde la web

1. En GitHub: **New repository** → nombre `super-domicilios` → **sin** README, .gitignore ni licencia → *Create*.
2. En la carpeta del proyecto:

```bash
git remote add origin https://github.com/<tu-usuario>/super-domicilios.git
git branch -M main
git push -u origin main
```

## Trabajo en equipo (recomendado para la sustentación)

* Agrega a tus compañeros en **Settings → Collaborators**.
* Una rama por funcionalidad y *Pull Request* hacia `main`:

```bash
git checkout -b feature/carrito
git add . && git commit -m "feat: ..."
git push -u origin feature/carrito
```

* El workflow `.github/workflows/ci.yml` compila y ejecuta las pruebas en cada push y pull request.
* Completa en `README.md` los nombres de los integrantes y pega la URL del repositorio en el reporte.
