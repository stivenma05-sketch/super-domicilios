# Guion de la exposición (15 minutos, solo diapositivas)

Esquema exigido: Problemática · Justificación · Metodología · Demostración · Conclusiones.
Reparte las secciones entre los integrantes del grupo. Recuerda: **no se permiten dispositivos de apoyo**, solo la presentación.

| Min | Sección | Diapositiva(s) | Contenido |
|---|---|---|---|
| 0:00–2:00 | **Problemática** | 1–2 | Los supermercados pequeños reciben pedidos por llamada o WhatsApp: errores en direcciones y cantidades, inventario desactualizado, sin seguimiento del pedido, sin reportes. El cliente no sabe en qué estado está su compra. |
| 2:00–4:00 | **Justificación** | 3–4 | Una sola solución con tres usuarios (cliente, repartidor, administrador), web + escritorio, mismo dominio y misma base de datos. Por qué .NET: tipado fuerte, EF Core, Identity, reutilización de la biblioteca base. |
| 4:00–6:30 | **Metodología** | 5–8 | Arquitectura en capas (diagrama de `README.md`): Core ← Data ← Web / Desktop. Patrones: MVC, repositorio, unidad de trabajo, estrategia (descuentos), máquina de estados. Pruebas xUnit sobre la lógica. Trabajo en GitHub (ramas, commits, CI). Estructuras de datos elegidas y por qué (tabla de `docs/ESTRUCTURAS_DE_DATOS.md`, con los tiempos medidos). |
| 6:30–12:00 | **Demostración** | 9–13 | Capturas/flujo: (1) Registro e inicio de sesión como Cliente. (2) Catálogo en celular y tablet (responsive). (3) Carrito, cupón y creación del pedido. (4) Admin: pasa a preparación. (5) Repartidor en escritorio: toma y entrega. (6) Reportes y página de estructuras. Muestra cómo cambia el estado en tiempo real entre web y escritorio. |
| 12:00–14:00 | **Conclusiones** | 14–15 | Se integraron todos los componentes vistos (clases, interfaces, genéricos, colecciones, LINQ, async, eventos, EF Core, Identity). Aprendizajes y dificultades. Trabajo futuro: pagos en línea, seguimiento en mapa, notificaciones, app móvil. |
| 14:00–15:00 | Preguntas | 16 | Prepárate para: ¿por qué `Dictionary` y no `List`? ¿cómo se evita vender sin stock? ¿cómo funcionan los roles? |

## Puntos técnicos para tener claros

* **Seguridad por rol**: `[Authorize(Roles = ...)]` en controladores; el rol Cliente se asigna solo al registrarse; las contraseñas las protege Identity (hash).
* **Integridad del pedido**: el servidor recalcula precios desde la base de datos (no confía en el carrito) y descuenta stock en la misma transacción (`IUnidadDeTrabajo`).
* **Cancelación**: devuelve el inventario. **Deshacer**: usa una pila con el historial de estados.
* **Responsive**: Bootstrap 5, `row-cols-1 row-cols-sm-2 row-cols-lg-4`, navbar colapsable, tablas con scroll horizontal.

## Reporte escrito (entregable)

Estructura sugerida (adaptable al formato que pida el profesor): portada con integrantes · problemática y justificación · requisitos · arquitectura (diagrama) · modelo de datos · estructuras de datos y comparativa · seguridad y roles · pruebas · capturas de pantalla web/escritorio/celular · conclusiones · enlace al repositorio de GitHub.
