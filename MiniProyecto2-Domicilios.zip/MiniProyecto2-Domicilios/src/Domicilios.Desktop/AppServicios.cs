using Domicilios.Core.Contratos;
using Domicilios.Core.Estructuras;
using Domicilios.Core.Servicios;
using Domicilios.Data;
using Domicilios.Data.Repositorios;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Domicilios.Desktop;

/// <summary>Contenedor de inyección de dependencias de la aplicación de escritorio (misma BD que la web).</summary>
public static class AppServicios
{
    public static IServiceProvider Proveedor { get; private set; } = null!;

    public static void Configurar()
    {
        var servicios = new ServiceCollection();
        servicios.AddLogging();
        servicios.AddDbContext<AppDbContext>(o => o.UseSqlite(ConfiguracionBD.CadenaPorDefecto()));
        servicios.AddIdentityCore<ApplicationUser>(ConfiguracionBD.ConfigurarIdentity)
                 .AddRoles<IdentityRole>()
                 .AddEntityFrameworkStores<AppDbContext>();

        servicios.AddScoped<IProductoRepositorio, ProductoRepositorio>();
        servicios.AddScoped<IPedidoRepositorio, PedidoRepositorio>();
        servicios.AddScoped<IUnidadDeTrabajo, UnidadDeTrabajo>();
        servicios.AddSingleton<CatalogoCupones>();
        servicios.AddScoped<PedidoService>();

        Proveedor = servicios.BuildServiceProvider();
    }

    /// <summary>Cada operación usa su propio alcance (y su propio DbContext).</summary>
    public static IServiceScope CrearAlcance() => Proveedor.CreateScope();
}

/// <summary>Usuario que inició sesión en el escritorio.</summary>
public record UsuarioActual(string Id, string Nombre, IReadOnlyList<string> Roles)
{
    public bool EsAdmin => Roles.Contains(Domicilios.Core.Entidades.RolesApp.Admin);
    public bool EsRepartidor => Roles.Contains(Domicilios.Core.Entidades.RolesApp.Repartidor);
}

public static class Sesion
{
    public static UsuarioActual Usuario { get; set; } = null!;
}
