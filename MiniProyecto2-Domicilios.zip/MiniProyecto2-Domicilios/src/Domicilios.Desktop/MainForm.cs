using Domicilios.Core;
using Domicilios.Core.Contratos;
using Domicilios.Core.Entidades;
using Domicilios.Core.Estructuras;
using Domicilios.Core.Servicios;
using Microsoft.Extensions.DependencyInjection;

namespace Domicilios.Desktop;

/// <summary>Fila que se muestra en la tabla de pedidos.</summary>
public record PedidoFila(int Id, string Fecha, string Cliente, string Zona, string Estado, string Repartidor, string Total);

public record ProductoFila(int Id, string Nombre, string Categoria, decimal Precio, int Stock, string Estado);

/// <summary>Ventana principal: pedidos, productos (solo Admin), reportes y comparativa de estructuras.</summary>
public class MainForm : Form
{
    private readonly UsuarioActual _usuario = Sesion.Usuario;

    // Pedidos
    private readonly ComboBox _filtroEstado = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 160 };
    private readonly DataGridView _gridPedidos = CrearGrid();
    private readonly Button _btnPreparar = new() { Text = "Preparar", AutoSize = true };
    private readonly Button _btnTomar = new() { Text = "Tomar pedido", AutoSize = true };
    private readonly Button _btnEntregar = new() { Text = "Marcar entregado", AutoSize = true };
    private readonly Button _btnCancelar = new() { Text = "Cancelar", AutoSize = true };
    private readonly Button _btnDeshacer = new() { Text = "Deshacer último cambio", AutoSize = true };

    // Productos
    private readonly DataGridView _gridProductos = CrearGrid();
    private readonly TextBox _txtNombre = new() { Width = 200 };
    private readonly NumericUpDown _numPrecio = new() { Maximum = 10_000_000, Increment = 100, Width = 100 };
    private readonly NumericUpDown _numStock = new() { Maximum = 100_000, Width = 80 };
    private readonly ComboBox _cmbCategoria = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 160 };
    private readonly CheckBox _chkActivo = new() { Text = "Activo", Checked = true, AutoSize = true };
    private int _productoSeleccionado;

    // Reportes y estructuras
    private readonly Label _lblResumen = new() { AutoSize = true, Font = new Font("Segoe UI", 11, FontStyle.Bold) };
    private readonly DataGridView _gridZonas = CrearGrid();
    private readonly DataGridView _gridTop = CrearGrid();
    private readonly DataGridView _gridEstructuras = CrearGrid();

    public MainForm()
    {
        Text = $"Super Domicilios - {_usuario.Nombre} ({string.Join(", ", _usuario.Roles)})";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1000, 650);
        MinimumSize = new Size(800, 500);

        var pestanas = new TabControl { Dock = DockStyle.Fill };
        pestanas.TabPages.Add(ConstruirPedidos());
        if (_usuario.EsAdmin)
        {
            pestanas.TabPages.Add(ConstruirProductos());
            pestanas.TabPages.Add(ConstruirReportes());
            pestanas.TabPages.Add(ConstruirEstructuras());
        }
        Controls.Add(pestanas);

        Load += async (_, _) => await CargarTodoAsync();
    }

    private static DataGridView CrearGrid() => new()
    {
        Dock = DockStyle.Fill,
        ReadOnly = true,
        AllowUserToAddRows = false,
        AllowUserToDeleteRows = false,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect,
        MultiSelect = false,
        AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
        RowHeadersVisible = false
    };

    private async Task CargarTodoAsync()
    {
        await RecargarPedidosAsync();
        if (_usuario.EsAdmin)
        {
            await RecargarProductosAsync();
            await RecargarReportesAsync();
        }
    }

    // ===================================================================== PEDIDOS =====
    private TabPage ConstruirPedidos()
    {
        _filtroEstado.Items.Add("Todos");
        foreach (var estado in Enum.GetValues<EstadoPedido>())
            _filtroEstado.Items.Add(estado.Descripcion());
        _filtroEstado.SelectedIndex = 0;
        _filtroEstado.SelectedIndexChanged += async (_, _) => await RecargarPedidosAsync();

        var actualizar = new Button { Text = "Actualizar", AutoSize = true };
        actualizar.Click += async (_, _) => await RecargarPedidosAsync();

        _btnPreparar.Click += async (_, _) => await EjecutarAsync(
            (s, id) => s.CambiarEstadoAsync(id, EstadoPedido.EnPreparacion, _usuario.Nombre));
        _btnTomar.Click += async (_, _) => await EjecutarAsync(
            (s, id) => s.TomarPedidoAsync(id, _usuario.Id, _usuario.Nombre));
        _btnEntregar.Click += async (_, _) => await EjecutarAsync(
            (s, id) => s.CambiarEstadoAsync(id, EstadoPedido.Entregado, _usuario.Nombre));
        _btnCancelar.Click += async (_, _) =>
        {
            if (MessageBox.Show("¿Cancelar el pedido seleccionado?", Text, MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question) == DialogResult.Yes)
                await EjecutarAsync((s, id) => s.CambiarEstadoAsync(id, EstadoPedido.Cancelado, _usuario.Nombre));
        };
        _btnDeshacer.Click += async (_, _) => await EjecutarAsync((s, id) => s.DeshacerUltimoCambioAsync(id));

        var barra = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(6) };
        barra.Controls.Add(new Label { Text = "Estado:", AutoSize = true, Margin = new Padding(0, 7, 0, 0) });
        barra.Controls.Add(_filtroEstado);
        barra.Controls.Add(actualizar);
        if (_usuario.EsAdmin)
        {
            barra.Controls.Add(_btnPreparar);
            barra.Controls.Add(_btnCancelar);
            barra.Controls.Add(_btnDeshacer);
        }
        if (_usuario.EsRepartidor)
            barra.Controls.Add(_btnTomar);
        barra.Controls.Add(_btnEntregar);

        var pagina = new TabPage("Pedidos");
        pagina.Controls.Add(_gridPedidos);
        pagina.Controls.Add(barra);
        return pagina;
    }

    private async Task RecargarPedidosAsync()
    {
        EstadoPedido? filtro = _filtroEstado.SelectedIndex > 0
            ? (EstadoPedido)(_filtroEstado.SelectedIndex - 1)
            : null;

        using var alcance = AppServicios.CrearAlcance();
        var servicio = alcance.ServiceProvider.GetRequiredService<PedidoService>();

        List<Pedido> pedidos;
        if (_usuario.EsAdmin)
        {
            pedidos = await servicio.ListarAsync(estado: filtro);
        }
        else
        {
            // El repartidor ve sus pedidos y los que están listos para tomar.
            var propios = await servicio.ListarAsync(repartidorId: _usuario.Id, estado: filtro);
            var listos = await servicio.ListarAsync(estado: EstadoPedido.EnPreparacion);
            pedidos = propios
                .Concat(listos.Where(p => p.RepartidorId is null))
                .DistinctBy(p => p.Id)
                .OrderByDescending(p => p.FechaCreacion)
                .ToList();
            if (filtro.HasValue)
                pedidos = pedidos.Where(p => p.Estado == filtro.Value).ToList();
        }

        _gridPedidos.DataSource = pedidos
            .Select(p => new PedidoFila(
                p.Id,
                p.FechaCreacion.ToLocalTime().ToString("dd/MM HH:mm"),
                p.ClienteNombre,
                p.Zona.ToString(),
                p.Estado.Descripcion(),
                p.RepartidorNombre ?? "-",
                p.Total.ComoPesos()))
            .ToList();
    }

    /// <summary>Ejecuta una operación del servicio sobre el pedido seleccionado y recarga la tabla.</summary>
    private async Task EjecutarAsync(Func<PedidoService, int, Task<Resultado<Pedido>>> operacion)
    {
        if (_gridPedidos.CurrentRow?.DataBoundItem is not PedidoFila fila)
        {
            MessageBox.Show("Selecciona un pedido.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using (var alcance = AppServicios.CrearAlcance())
        {
            var servicio = alcance.ServiceProvider.GetRequiredService<PedidoService>();
            var resultado = await operacion(servicio, fila.Id);
            if (!resultado.Exito)
                MessageBox.Show(resultado.Error, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        await RecargarPedidosAsync();
        if (_usuario.EsAdmin)
            await RecargarReportesAsync();
    }

    // =================================================================== PRODUCTOS =====
    private TabPage ConstruirProductos()
    {
        _gridProductos.SelectionChanged += (_, _) => MostrarProductoSeleccionado();

        var nuevo = new Button { Text = "Nuevo", AutoSize = true };
        nuevo.Click += (_, _) => LimpiarFormularioProducto();
        var guardar = new Button { Text = "Guardar", AutoSize = true };
        guardar.Click += async (_, _) => await GuardarProductoAsync();

        var formulario = new FlowLayoutPanel { Dock = DockStyle.Bottom, AutoSize = true, Padding = new Padding(6) };
        formulario.Controls.Add(new Label { Text = "Nombre", AutoSize = true, Margin = new Padding(0, 7, 0, 0) });
        formulario.Controls.Add(_txtNombre);
        formulario.Controls.Add(new Label { Text = "Precio", AutoSize = true, Margin = new Padding(0, 7, 0, 0) });
        formulario.Controls.Add(_numPrecio);
        formulario.Controls.Add(new Label { Text = "Stock", AutoSize = true, Margin = new Padding(0, 7, 0, 0) });
        formulario.Controls.Add(_numStock);
        formulario.Controls.Add(new Label { Text = "Categoría", AutoSize = true, Margin = new Padding(0, 7, 0, 0) });
        formulario.Controls.Add(_cmbCategoria);
        formulario.Controls.Add(_chkActivo);
        formulario.Controls.Add(nuevo);
        formulario.Controls.Add(guardar);

        var pagina = new TabPage("Productos");
        pagina.Controls.Add(_gridProductos);
        pagina.Controls.Add(formulario);
        return pagina;
    }

    private async Task RecargarProductosAsync()
    {
        using var alcance = AppServicios.CrearAlcance();
        var repo = alcance.ServiceProvider.GetRequiredService<IProductoRepositorio>();

        var categorias = await repo.ListarCategoriasAsync();
        _cmbCategoria.DataSource = categorias;
        _cmbCategoria.DisplayMember = nameof(Categoria.Nombre);
        _cmbCategoria.ValueMember = nameof(Categoria.Id);

        var productos = await repo.ListarAsync(soloActivos: false);
        _gridProductos.DataSource = productos
            .Select(p => new ProductoFila(p.Id, p.Nombre, p.Categoria?.Nombre ?? "-", p.Precio, p.Stock,
                                          p.Activo ? "Activo" : "Inactivo"))
            .ToList();
    }

    private void MostrarProductoSeleccionado()
    {
        if (_gridProductos.CurrentRow?.DataBoundItem is not ProductoFila fila)
            return;

        _productoSeleccionado = fila.Id;
        _txtNombre.Text = fila.Nombre;
        _numPrecio.Value = Math.Min(fila.Precio, _numPrecio.Maximum);
        _numStock.Value = Math.Min(fila.Stock, _numStock.Maximum);
        _chkActivo.Checked = fila.Estado == "Activo";

        var indice = _cmbCategoria.FindStringExact(fila.Categoria);
        if (indice >= 0)
            _cmbCategoria.SelectedIndex = indice;
    }

    private void LimpiarFormularioProducto()
    {
        _productoSeleccionado = 0;
        _gridProductos.ClearSelection();
        _txtNombre.Clear();
        _numPrecio.Value = 0;
        _numStock.Value = 0;
        _chkActivo.Checked = true;
        _txtNombre.Focus();
    }

    private async Task GuardarProductoAsync()
    {
        if (string.IsNullOrWhiteSpace(_txtNombre.Text) || _numPrecio.Value <= 0 || _cmbCategoria.SelectedValue is not int categoriaId)
        {
            MessageBox.Show("Completa nombre, precio mayor que cero y categoría.", Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        using (var alcance = AppServicios.CrearAlcance())
        {
            var repo = alcance.ServiceProvider.GetRequiredService<IProductoRepositorio>();
            var unidad = alcance.ServiceProvider.GetRequiredService<IUnidadDeTrabajo>();

            var producto = _productoSeleccionado == 0 ? new Producto() : await repo.ObtenerAsync(_productoSeleccionado);
            if (producto is null)
            {
                MessageBox.Show("El producto ya no existe.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            producto.Nombre = _txtNombre.Text.Trim();
            producto.Precio = _numPrecio.Value;
            producto.Stock = (int)_numStock.Value;
            producto.CategoriaId = categoriaId;
            producto.Activo = _chkActivo.Checked;

            if (_productoSeleccionado == 0)
                await repo.AgregarAsync(producto);
            await unidad.GuardarCambiosAsync();
        }

        await RecargarProductosAsync();
        LimpiarFormularioProducto();
    }

    // =================================================================== REPORTES ======
    private TabPage ConstruirReportes()
    {
        var actualizar = new Button { Text = "Actualizar", AutoSize = true };
        actualizar.Click += async (_, _) => await RecargarReportesAsync();

        var tabla = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2 };
        tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        tabla.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        tabla.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        tabla.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        tabla.Controls.Add(new Label { Text = "Ventas por zona", AutoSize = true }, 0, 0);
        tabla.Controls.Add(new Label { Text = "Productos más vendidos", AutoSize = true }, 1, 0);
        tabla.Controls.Add(_gridZonas, 0, 1);
        tabla.Controls.Add(_gridTop, 1, 1);

        var cabecera = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(6) };
        cabecera.Controls.Add(actualizar);
        cabecera.Controls.Add(_lblResumen);

        var pagina = new TabPage("Reportes");
        pagina.Controls.Add(tabla);
        pagina.Controls.Add(cabecera);
        return pagina;
    }

    private async Task RecargarReportesAsync()
    {
        using var alcance = AppServicios.CrearAlcance();
        var servicio = alcance.ServiceProvider.GetRequiredService<PedidoService>();
        var pedidos = await servicio.ListarAsync();

        var resumen = ReporteService.Resumen(pedidos);
        _lblResumen.Text =
            $"  Pedidos: {resumen.TotalPedidos}   Entregados: {resumen.Entregados}   " +
            $"Ingresos: {resumen.Ingresos.ComoPesos()}   Ticket promedio: {resumen.TicketPromedio.ComoPesos()}";

        _gridZonas.DataSource = ReporteService.VentasPorZona(pedidos).Values
            .Select(z => new { Zona = z.Zona.ToString(), z.Pedidos, Total = z.Total.ComoPesos() })
            .ToList();
        _gridTop.DataSource = ReporteService.TopProductos(pedidos, 5)
            .Select(v => new { Producto = v.Nombre, v.Unidades, Ingresos = v.Ingresos.ComoPesos() })
            .ToList();
    }

    // ================================================================ ESTRUCTURAS ======
    private TabPage ConstruirEstructuras()
    {
        var ejecutar = new Button { Text = "Ejecutar comparativa", AutoSize = true };
        ejecutar.Click += async (_, _) =>
        {
            ejecutar.Enabled = false;
            var resultados = await Task.Run(() => ComparadorEstructuras.Ejecutar());
            _gridEstructuras.DataSource = resultados;
            ejecutar.Enabled = true;
        };

        var cabecera = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(6) };
        cabecera.Controls.Add(ejecutar);
        cabecera.Controls.Add(new Label
        {
            Text = "Mide List, HashSet, Dictionary, SortedDictionary y Queue con el mismo trabajo.",
            AutoSize = true,
            Margin = new Padding(8, 7, 0, 0)
        });

        var pagina = new TabPage("Estructuras de datos");
        pagina.Controls.Add(_gridEstructuras);
        pagina.Controls.Add(cabecera);
        return pagina;
    }
}
