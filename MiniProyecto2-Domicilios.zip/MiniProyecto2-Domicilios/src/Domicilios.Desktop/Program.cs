using Domicilios.Data;

namespace Domicilios.Desktop;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        AppServicios.Configurar();

        try
        {
            DbInicializador.InicializarAsync(AppServicios.Proveedor).GetAwaiter().GetResult();
        }
        catch (Exception ex)
        {
            MessageBox.Show("No se pudo abrir la base de datos:\n" + ex.Message, "Super Domicilios",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        using var login = new LoginForm();
        if (login.ShowDialog() != DialogResult.OK)
            return;

        Application.Run(new MainForm());
    }
}
