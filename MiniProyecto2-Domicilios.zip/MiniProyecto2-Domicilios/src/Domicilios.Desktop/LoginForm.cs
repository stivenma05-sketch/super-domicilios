using Domicilios.Core.Entidades;
using Domicilios.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;

namespace Domicilios.Desktop;

/// <summary>Inicio de sesión con ASP.NET Core Identity. Solo Admin y Repartidor pueden usar el escritorio.</summary>
public class LoginForm : Form
{
    private readonly TextBox _correo = new() { Text = "admin@domicilios.com", Dock = DockStyle.Fill };
    private readonly TextBox _clave = new() { UseSystemPasswordChar = true, Dock = DockStyle.Fill };
    private readonly Button _ingresar = new() { Text = "Ingresar", Dock = DockStyle.Fill, Height = 34 };

    public LoginForm()
    {
        Text = "Super Domicilios - Ingresar";
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ClientSize = new Size(380, 220);

        var tabla = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(16),
            ColumnCount = 1,
            RowCount = 6
        };
        tabla.Controls.Add(new Label { Text = "Correo", AutoSize = true });
        tabla.Controls.Add(_correo);
        tabla.Controls.Add(new Label { Text = "Contraseña", AutoSize = true });
        tabla.Controls.Add(_clave);
        tabla.Controls.Add(_ingresar);
        tabla.Controls.Add(new Label
        {
            Text = "Roles permitidos: Admin y Repartidor",
            AutoSize = true,
            ForeColor = Color.Gray
        });
        Controls.Add(tabla);

        AcceptButton = _ingresar;
        _ingresar.Click += async (_, _) => await IngresarAsync();
    }

    private async Task IngresarAsync()
    {
        _ingresar.Enabled = false;
        try
        {
            using var alcance = AppServicios.CrearAlcance();
            var usuarios = alcance.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

            var usuario = await usuarios.FindByEmailAsync(_correo.Text.Trim());
            if (usuario is null || !await usuarios.CheckPasswordAsync(usuario, _clave.Text))
            {
                MessageBox.Show("Correo o contraseña incorrectos.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var roles = (await usuarios.GetRolesAsync(usuario)).ToList();
            if (!roles.Contains(RolesApp.Admin) && !roles.Contains(RolesApp.Repartidor))
            {
                MessageBox.Show("Esta aplicación es solo para administradores y repartidores.", Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Sesion.Usuario = new UsuarioActual(usuario.Id, usuario.NombreCompleto, roles);
            DialogResult = DialogResult.OK;
            Close();
        }
        finally
        {
            _ingresar.Enabled = true;
        }
    }
}
