using Domicilios.Core.Entidades;

namespace Domicilios.Core.Descuentos;

/// <summary>
/// Patrón Estrategia: cada tipo de cupón calcula su descuento de forma distinta.
/// Demuestra clases abstractas, herencia y polimorfismo.
/// </summary>
public abstract class Descuento
{
    public abstract string Descripcion { get; }
    public abstract Dinero Calcular(Dinero subtotal);
}

public sealed class SinDescuento : Descuento
{
    public override string Descripcion => "Sin descuento";
    public override Dinero Calcular(Dinero subtotal) => Dinero.Cero;
}

public sealed class DescuentoPorcentaje : Descuento
{
    private readonly decimal _porcentaje;

    public DescuentoPorcentaje(decimal porcentaje)
    {
        if (porcentaje <= 0 || porcentaje > 100)
            throw new ArgumentOutOfRangeException(nameof(porcentaje), "El porcentaje debe estar entre 0 y 100.");
        _porcentaje = porcentaje;
    }

    public override string Descripcion => $"{_porcentaje:0.##}% de descuento";

    public override Dinero Calcular(Dinero subtotal) =>
        new(Math.Round(subtotal.Valor * _porcentaje / 100m, 0));
}

public sealed class DescuentoMontoFijo : Descuento
{
    private readonly decimal _monto;
    private readonly decimal _compraMinima;

    public DescuentoMontoFijo(decimal monto, decimal compraMinima)
    {
        _monto = monto;
        _compraMinima = compraMinima;
    }

    public override string Descripcion =>
        $"{new Dinero(_monto)} de descuento en compras desde {new Dinero(_compraMinima)}";

    public override Dinero Calcular(Dinero subtotal) =>
        subtotal.Valor >= _compraMinima ? new Dinero(_monto) : Dinero.Cero;
}
