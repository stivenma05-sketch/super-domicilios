using Domicilios.Core.Entidades;

namespace Domicilios.Core.Contratos;

/// <summary>
/// Contratos que la capa de datos (EF Core) debe implementar. La lógica de negocio
/// solo conoce estas interfaces, así se puede probar sin base de datos.
/// </summary>
public interface IProductoRepositorio
{
    Task<List<Producto>> ListarAsync(int? categoriaId = null, string? busqueda = null, bool soloActivos = true);
    Task<Producto?> ObtenerAsync(int id);
    Task<List<Categoria>> ListarCategoriasAsync();
    Task AgregarAsync(Producto producto);
    Task ActualizarAsync(Producto producto);
}

public interface IPedidoRepositorio
{
    /// <summary>Devuelve el pedido con sus ítems e historial.</summary>
    Task<Pedido?> ObtenerAsync(int id);

    Task<List<Pedido>> ListarAsync(string? clienteId = null, string? repartidorId = null, EstadoPedido? estado = null);

    Task AgregarAsync(Pedido pedido);
}

/// <summary>Patrón Unidad de Trabajo: confirma en una sola transacción todos los cambios pendientes.</summary>
public interface IUnidadDeTrabajo
{
    Task<int> GuardarCambiosAsync();
}
