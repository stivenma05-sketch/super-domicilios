namespace Domicilios.Core;

/// <summary>Resultado de una operación de negocio (evita usar excepciones para errores esperados).</summary>
public class Resultado
{
    public bool Exito { get; }
    public string? Error { get; }

    protected Resultado(bool exito, string? error)
    {
        Exito = exito;
        Error = error;
    }

    public static Resultado Ok() => new(true, null);
    public static Resultado Fallo(string error) => new(false, error);
}

/// <summary>Versión genérica que además transporta un valor.</summary>
public class Resultado<T> : Resultado
{
    public T? Valor { get; }

    private Resultado(bool exito, T? valor, string? error) : base(exito, error)
    {
        Valor = valor;
    }

    public static Resultado<T> Ok(T valor) => new(true, valor, null);
    public static new Resultado<T> Fallo(string error) => new(false, default, error);
}
