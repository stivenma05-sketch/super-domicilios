using Domicilios.Core.Contratos;
using Domicilios.Core.Entidades;
using Domicilios.Core.Estructuras;

namespace Domicilios.Core.Servicios;

/// <summary>Datos que acompañan al evento <see cref="PedidoService.EstadoCambiado"/>.</summary>
public class CambioEstadoEventArgs : EventArgs
{
    public int PedidoId { get; }
    public EstadoPedido Anterior { get; }
    public EstadoPedido Nuevo { get; }
    public string Usuario { get; }

    public CambioEstadoEventArgs(int pedidoId, EstadoPedido anterior, EstadoPedido nuevo, string usuario)
    {
        PedidoId = pedidoId;
        Anterior = anterior;
        Nuevo = nuevo;
        Usuario = usuario;
    }
}

/// <summary>Lógica de negocio de los pedidos a domicilio.</summary>
public class PedidoService
{
    /// <summary>
    /// Máquina de estados: Dictionary (estado actual) -> HashSet de estados permitidos.
    /// HashSet evita duplicados y valida una transición en O(1).
    /// </summary>
    private static readonly Dictionary<EstadoPedido, HashSet<EstadoPedido>> Transiciones = new()
    {
        [EstadoPedido.Pendiente] = new() { EstadoPedido.EnPreparacion, EstadoPedido.Cancelado },
        [EstadoPedido.EnPreparacion] = new() { EstadoPedido.EnCamino, EstadoPedido.Cancelado },
        [EstadoPedido.EnCamino] = new() { EstadoPedido.Entregado },
        [EstadoPedido.Entregado] = new(),
        [EstadoPedido.Cancelado] = new()
    };

    private readonly IProductoRepositorio _productos;
    private readonly IPedidoRepositorio _pedidos;
    private readonly IUnidadDeTrabajo _unidad;
    private readonly CatalogoCupones _cupones;

    /// <summary>Se dispara cada vez que un pedido cambia de estado (ej. para notificar al cliente).</summary>
    public event EventHandler<CambioEstadoEventArgs>? EstadoCambiado;

    public PedidoService(IProductoRepositorio productos, IPedidoRepositorio pedidos,
                         IUnidadDeTrabajo unidad, CatalogoCupones cupones)
    {
        _productos = productos;
        _pedidos = pedidos;
        _unidad = unidad;
        _cupones = cupones;
    }

    public static bool EsTransicionValida(EstadoPedido actual, EstadoPedido nuevo) =>
        Transiciones.TryGetValue(actual, out var permitidos) && permitidos.Contains(nuevo);

    public ResumenPedido Previsualizar(CarritoCompras carrito, ZonaEntrega zona, string? cupon) =>
        CalculadoraPedido.Calcular(carrito.Subtotal, zona, _cupones.Obtener(cupon));

    public async Task<Resultado<Pedido>> CrearPedidoAsync(string clienteId, string clienteNombre,
        CarritoCompras carrito, string direccion, ZonaEntrega zona, string? cupon)
    {
        if (string.IsNullOrWhiteSpace(direccion))
            return Resultado<Pedido>.Fallo("La dirección de entrega es obligatoria.");
        if (carrito.Cantidad == 0)
            return Resultado<Pedido>.Fallo("El carrito está vacío.");
        if (!string.IsNullOrWhiteSpace(cupon) && !_cupones.Existe(cupon))
            return Resultado<Pedido>.Fallo("El cupón ingresado no es válido.");

        // 1) Validar todo antes de modificar nada. Se usa el precio de la base de datos, no el del carrito.
        var lineas = new List<(Producto Producto, int Cantidad)>();
        foreach (var item in carrito)
        {
            var producto = await _productos.ObtenerAsync(item.ProductoId);
            if (producto is null || !producto.Activo)
                return Resultado<Pedido>.Fallo($"'{item.Nombre}' ya no está disponible.");
            if (!producto.HayStock(item.Cantidad))
                return Resultado<Pedido>.Fallo($"Stock insuficiente de '{producto.Nombre}'. Disponible: {producto.Stock}.");
            lineas.Add((producto, item.Cantidad));
        }

        // 2) Descontar inventario y armar el pedido.
        var pedido = new Pedido
        {
            ClienteId = clienteId,
            ClienteNombre = clienteNombre,
            DireccionEntrega = direccion.Trim(),
            Zona = zona,
            CodigoCupon = string.IsNullOrWhiteSpace(cupon) ? null : cupon.Trim().ToUpperInvariant(),
            FechaCreacion = DateTime.UtcNow
        };

        foreach (var (producto, cantidad) in lineas)
        {
            producto.Stock -= cantidad;
            pedido.Items.Add(new PedidoItem
            {
                ProductoId = producto.Id,
                NombreProducto = producto.Nombre,
                PrecioUnitario = producto.Precio,
                Cantidad = cantidad
            });
        }

        var subtotal = new Dinero(pedido.Items.Sum(i => i.Subtotal));
        var resumen = CalculadoraPedido.Calcular(subtotal, zona, _cupones.Obtener(cupon));
        pedido.Subtotal = resumen.Subtotal.Valor;
        pedido.Descuento = resumen.Descuento.Valor;
        pedido.CostoDomicilio = resumen.Domicilio.Valor;
        pedido.Total = resumen.Total.Valor;

        pedido.Historial.Add(new CambioEstado { Estado = EstadoPedido.Pendiente, Usuario = clienteNombre });

        await _pedidos.AgregarAsync(pedido);
        await _unidad.GuardarCambiosAsync();   // pedido + stock en una sola transacción
        return Resultado<Pedido>.Ok(pedido);
    }

    public async Task<Resultado<Pedido>> CambiarEstadoAsync(int pedidoId, EstadoPedido nuevo, string usuario)
    {
        var pedido = await _pedidos.ObtenerAsync(pedidoId);
        if (pedido is null)
            return Resultado<Pedido>.Fallo("El pedido no existe.");

        var error = await AplicarCambioAsync(pedido, nuevo, usuario);
        if (error is not null)
            return Resultado<Pedido>.Fallo(error);

        await _unidad.GuardarCambiosAsync();
        return Resultado<Pedido>.Ok(pedido);
    }

    /// <summary>Un repartidor toma un pedido listo: queda asignado a él y pasa a "En camino".</summary>
    public async Task<Resultado<Pedido>> TomarPedidoAsync(int pedidoId, string repartidorId, string repartidorNombre)
    {
        var pedido = await _pedidos.ObtenerAsync(pedidoId);
        if (pedido is null)
            return Resultado<Pedido>.Fallo("El pedido no existe.");
        if (pedido.Estado != EstadoPedido.EnPreparacion || pedido.RepartidorId is not null)
            return Resultado<Pedido>.Fallo("Este pedido no está disponible para tomar.");

        var error = await AplicarCambioAsync(pedido, EstadoPedido.EnCamino, repartidorNombre);
        if (error is not null)
            return Resultado<Pedido>.Fallo(error);

        pedido.RepartidorId = repartidorId;
        pedido.RepartidorNombre = repartidorNombre;
        await _unidad.GuardarCambiosAsync();
        return Resultado<Pedido>.Ok(pedido);
    }

    /// <summary>
    /// Revierte el último cambio de estado. Usa una pila (LIFO): el último estado
    /// registrado es el primero en deshacerse.
    /// </summary>
    public async Task<Resultado<Pedido>> DeshacerUltimoCambioAsync(int pedidoId)
    {
        var pedido = await _pedidos.ObtenerAsync(pedidoId);
        if (pedido is null)
            return Resultado<Pedido>.Fallo("El pedido no existe.");

        var pila = new Stack<CambioEstado>(pedido.Historial.OrderBy(h => h.Fecha).ThenBy(h => h.Id));
        if (pila.Count < 2)
            return Resultado<Pedido>.Fallo("No hay cambios que deshacer.");

        var ultimo = pila.Pop();
        var anterior = pila.Peek();

        if (ultimo.Estado is EstadoPedido.Entregado or EstadoPedido.Cancelado)
            return Resultado<Pedido>.Fallo("Un pedido finalizado no se puede revertir.");

        pedido.Historial.Remove(ultimo);
        pedido.Estado = anterior.Estado;
        if (ultimo.Estado == EstadoPedido.EnCamino)
        {
            pedido.RepartidorId = null;
            pedido.RepartidorNombre = null;
        }

        await _unidad.GuardarCambiosAsync();
        return Resultado<Pedido>.Ok(pedido);
    }

    /// <summary>Aplica el cambio en memoria. Devuelve un mensaje de error o null si todo salió bien.</summary>
    private async Task<string?> AplicarCambioAsync(Pedido pedido, EstadoPedido nuevo, string usuario)
    {
        if (!EsTransicionValida(pedido.Estado, nuevo))
            return $"No se puede pasar de '{pedido.Estado.Descripcion()}' a '{nuevo.Descripcion()}'.";

        // Si se cancela, el inventario se devuelve.
        if (nuevo == EstadoPedido.Cancelado)
        {
            foreach (var item in pedido.Items)
            {
                var producto = await _productos.ObtenerAsync(item.ProductoId);
                if (producto is not null)
                    producto.Stock += item.Cantidad;
            }
        }

        var anterior = pedido.Estado;
        pedido.Estado = nuevo;
        pedido.Historial.Add(new CambioEstado { PedidoId = pedido.Id, Estado = nuevo, Usuario = usuario });

        EstadoCambiado?.Invoke(this, new CambioEstadoEventArgs(pedido.Id, anterior, nuevo, usuario));
        return null;
    }

    public Task<Pedido?> ObtenerAsync(int id) => _pedidos.ObtenerAsync(id);

    public Task<List<Pedido>> ListarAsync(string? clienteId = null, string? repartidorId = null, EstadoPedido? estado = null) =>
        _pedidos.ListarAsync(clienteId, repartidorId, estado);
}
