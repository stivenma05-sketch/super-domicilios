using Domicilios.Core.Descuentos;
using Domicilios.Core.Entidades;
using Domicilios.Core.Estructuras;

namespace Domicilios.Core.Servicios;

/// <summary>Desglose de valores de un pedido (record inmutable).</summary>
public record ResumenPedido(Dinero Subtotal, Dinero Descuento, Dinero Domicilio, Dinero Total, string? DescripcionDescuento);

public static class CalculadoraPedido
{
    public static ResumenPedido Calcular(Dinero subtotal, ZonaEntrega zona, Descuento descuento)
    {
        // El descuento nunca puede superar el valor de la compra.
        var valorDescuento = new Dinero(Math.Min(descuento.Calcular(subtotal).Valor, subtotal.Valor));
        var valorCompra = subtotal - valorDescuento;
        var domicilio = TarifaDomicilio.Calcular(zona, valorCompra);

        return new ResumenPedido(
            subtotal,
            valorDescuento,
            domicilio,
            valorCompra + domicilio,
            descuento is SinDescuento ? null : descuento.Descripcion);
    }
}
