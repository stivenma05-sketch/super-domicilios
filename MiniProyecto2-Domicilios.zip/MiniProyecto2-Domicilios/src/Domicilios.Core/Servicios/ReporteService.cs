using Domicilios.Core.Entidades;

namespace Domicilios.Core.Servicios;

public record VentaZona(ZonaEntrega Zona, int Pedidos, decimal Total);
public record ProductoVendido(string Nombre, int Unidades, decimal Ingresos);
public record VentaDia(DateOnly Dia, int Pedidos, decimal Total);
public record ResumenVentas(int TotalPedidos, int Entregados, int Cancelados, decimal Ingresos, decimal TicketPromedio);

/// <summary>Reportes con LINQ. Las funciones son puras (reciben datos, devuelven datos) y fáciles de probar.</summary>
public static class ReporteService
{
    private static IEnumerable<Pedido> Validos(IEnumerable<Pedido> pedidos) =>
        pedidos.Where(p => p.Estado != EstadoPedido.Cancelado);

    public static ResumenVentas Resumen(IEnumerable<Pedido> pedidos)
    {
        var todos = pedidos.ToList();
        var validos = Validos(todos).ToList();
        var ingresos = validos.Sum(p => p.Total);
        var ticket = validos.Count == 0 ? 0m : Math.Round(ingresos / validos.Count, 0);

        return new ResumenVentas(
            todos.Count,
            todos.Count(p => p.Estado == EstadoPedido.Entregado),
            todos.Count(p => p.Estado == EstadoPedido.Cancelado),
            ingresos,
            ticket);
    }

    /// <summary>SortedDictionary mantiene las zonas ordenadas para mostrarlas siempre igual.</summary>
    public static SortedDictionary<ZonaEntrega, VentaZona> VentasPorZona(IEnumerable<Pedido> pedidos) =>
        new(Validos(pedidos)
            .GroupBy(p => p.Zona)
            .ToDictionary(g => g.Key, g => new VentaZona(g.Key, g.Count(), g.Sum(p => p.Total))));

    public static List<ProductoVendido> TopProductos(IEnumerable<Pedido> pedidos, int cantidad = 5) =>
        Validos(pedidos)
            .SelectMany(p => p.Items)
            .GroupBy(i => i.NombreProducto)
            .Select(g => new ProductoVendido(g.Key, g.Sum(i => i.Cantidad), g.Sum(i => i.Subtotal)))
            .OrderByDescending(v => v.Unidades)
            .ThenBy(v => v.Nombre)
            .Take(cantidad)
            .ToList();

    public static List<VentaDia> VentasPorDia(IEnumerable<Pedido> pedidos) =>
        Validos(pedidos)
            .GroupBy(p => DateOnly.FromDateTime(p.FechaCreacion))
            .Select(g => new VentaDia(g.Key, g.Count(), g.Sum(p => p.Total)))
            .OrderBy(v => v.Dia)
            .ToList();
}
