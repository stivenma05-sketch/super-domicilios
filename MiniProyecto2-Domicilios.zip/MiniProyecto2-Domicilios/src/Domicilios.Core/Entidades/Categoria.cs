using System.ComponentModel.DataAnnotations;

namespace Domicilios.Core.Entidades;

public class Categoria
{
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio")]
    [StringLength(60)]
    public string Nombre { get; set; } = string.Empty;

    /// <summary>Emoji usado como "imagen" de la categoría en la interfaz.</summary>
    [StringLength(8)]
    public string Icono { get; set; } = "🛒";

    public ICollection<Producto> Productos { get; set; } = new List<Producto>();
}
