using System.Globalization;

namespace Domicilios.Core.Entidades;

/// <summary>
/// Tipo valor inmutable para montos en pesos colombianos.
/// Demuestra: record struct, sobrecarga de operadores y conversión implícita.
/// </summary>
public readonly record struct Dinero(decimal Valor)
{
    public static Dinero Cero => new(0m);

    public static Dinero operator +(Dinero a, Dinero b) => new(a.Valor + b.Valor);
    public static Dinero operator -(Dinero a, Dinero b) => new(a.Valor - b.Valor);
    public static Dinero operator *(Dinero a, int cantidad) => new(a.Valor * cantidad);

    public static implicit operator Dinero(decimal valor) => new(valor);

    /// <summary>Formato "$12.500" sin depender de la cultura del sistema.</summary>
    public override string ToString() =>
        "$" + Valor.ToString("N0", CultureInfo.InvariantCulture).Replace(',', '.');
}
