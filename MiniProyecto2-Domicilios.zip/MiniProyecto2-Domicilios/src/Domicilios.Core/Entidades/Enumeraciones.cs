namespace Domicilios.Core.Entidades;

/// <summary>Ciclo de vida de un pedido a domicilio.</summary>
public enum EstadoPedido
{
    Pendiente = 0,
    EnPreparacion = 1,
    EnCamino = 2,
    Entregado = 3,
    Cancelado = 4
}

/// <summary>Zonas de la ciudad con tarifa de domicilio propia.</summary>
public enum ZonaEntrega
{
    Centro = 0,
    Norte = 1,
    Sur = 2,
    Oriente = 3,
    Occidente = 4
}

/// <summary>Nombres de los roles de la aplicación (ASP.NET Core Identity).</summary>
public static class RolesApp
{
    public const string Admin = "Admin";
    public const string Cliente = "Cliente";
    public const string Repartidor = "Repartidor";

    public static readonly string[] Todos = { Admin, Cliente, Repartidor };
}
