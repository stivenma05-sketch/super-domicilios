using System.ComponentModel.DataAnnotations;

namespace Domicilios.Core.Entidades;

public class Producto
{
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio")]
    [StringLength(100)]
    public string Nombre { get; set; } = string.Empty;

    [StringLength(250)]
    public string? Descripcion { get; set; }

    [Range(1, 100_000_000, ErrorMessage = "El precio debe ser mayor que cero")]
    public decimal Precio { get; set; }

    [Range(0, 100_000, ErrorMessage = "El stock no puede ser negativo")]
    public int Stock { get; set; }

    /// <summary>Unidad de venta (und, kg, lb, litro...).</summary>
    [StringLength(20)]
    public string Unidad { get; set; } = "und";

    /// <summary>Si es false el producto ya no se muestra ni se puede pedir (borrado lógico).</summary>
    public bool Activo { get; set; } = true;

    [Display(Name = "Categoría")]
    public int CategoriaId { get; set; }

    public Categoria? Categoria { get; set; }

    public bool HayStock(int cantidad) => Activo && Stock >= cantidad;
}
