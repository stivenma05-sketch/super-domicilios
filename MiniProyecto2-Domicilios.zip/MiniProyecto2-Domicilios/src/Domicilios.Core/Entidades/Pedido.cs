using System.ComponentModel.DataAnnotations;

namespace Domicilios.Core.Entidades;

public class Pedido : IComparable<Pedido>
{
    public int Id { get; set; }

    [Required]
    public string ClienteId { get; set; } = string.Empty;

    [Required, StringLength(120)]
    public string ClienteNombre { get; set; } = string.Empty;

    public string? RepartidorId { get; set; }

    [StringLength(120)]
    public string? RepartidorNombre { get; set; }

    public DateTime FechaCreacion { get; set; } = DateTime.UtcNow;

    public EstadoPedido Estado { get; set; } = EstadoPedido.Pendiente;

    [Required(ErrorMessage = "La dirección es obligatoria"), StringLength(200)]
    public string DireccionEntrega { get; set; } = string.Empty;

    public ZonaEntrega Zona { get; set; }

    [StringLength(30)]
    public string? CodigoCupon { get; set; }

    public decimal Subtotal { get; set; }
    public decimal Descuento { get; set; }
    public decimal CostoDomicilio { get; set; }
    public decimal Total { get; set; }

    public List<PedidoItem> Items { get; set; } = new();
    public List<CambioEstado> Historial { get; set; } = new();

    // Propiedad calculada (sin setter => EF Core no la mapea).
    public int TotalUnidades => Items.Sum(i => i.Cantidad);

    /// <summary>Orden natural: el más antiguo primero (útil para la cola de despacho).</summary>
    public int CompareTo(Pedido? otro) =>
        otro is null ? 1 : FechaCreacion.CompareTo(otro.FechaCreacion);
}

public class PedidoItem
{
    public int Id { get; set; }
    public int PedidoId { get; set; }
    public int ProductoId { get; set; }

    /// <summary>Copia del nombre/precio al momento de la compra (el catálogo puede cambiar después).</summary>
    [StringLength(100)]
    public string NombreProducto { get; set; } = string.Empty;

    public decimal PrecioUnitario { get; set; }
    public int Cantidad { get; set; }

    public decimal Subtotal => PrecioUnitario * Cantidad;
}

public class CambioEstado
{
    public int Id { get; set; }
    public int PedidoId { get; set; }
    public EstadoPedido Estado { get; set; }
    public DateTime Fecha { get; set; } = DateTime.UtcNow;

    [StringLength(120)]
    public string Usuario { get; set; } = string.Empty;
}
