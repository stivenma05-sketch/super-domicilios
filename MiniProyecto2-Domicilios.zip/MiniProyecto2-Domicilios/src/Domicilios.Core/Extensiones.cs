using Domicilios.Core.Entidades;

namespace Domicilios.Core;

/// <summary>Métodos de extensión de uso común en la interfaz.</summary>
public static class Extensiones
{
    public static string ComoPesos(this decimal valor) => new Dinero(valor).ToString();

    public static string Descripcion(this EstadoPedido estado) => estado switch
    {
        EstadoPedido.Pendiente => "Pendiente",
        EstadoPedido.EnPreparacion => "En preparación",
        EstadoPedido.EnCamino => "En camino",
        EstadoPedido.Entregado => "Entregado",
        EstadoPedido.Cancelado => "Cancelado",
        _ => estado.ToString()
    };

    /// <summary>Clase de Bootstrap asociada al estado (badge de color).</summary>
    public static string ClaseColor(this EstadoPedido estado) => estado switch
    {
        EstadoPedido.Pendiente => "warning",
        EstadoPedido.EnPreparacion => "info",
        EstadoPedido.EnCamino => "primary",
        EstadoPedido.Entregado => "success",
        EstadoPedido.Cancelado => "secondary",
        _ => "light"
    };
}
