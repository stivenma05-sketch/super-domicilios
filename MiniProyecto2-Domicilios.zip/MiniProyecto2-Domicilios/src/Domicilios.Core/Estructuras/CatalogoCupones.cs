using Domicilios.Core.Descuentos;

namespace Domicilios.Core.Estructuras;

/// <summary>
/// Catálogo de cupones. Un <see cref="Dictionary{TKey,TValue}"/> con comparador que ignora
/// mayúsculas permite validar "bienvenido10" o "BIENVENIDO10" en O(1).
/// </summary>
public class CatalogoCupones
{
    private readonly Dictionary<string, Descuento> _cupones = new(StringComparer.OrdinalIgnoreCase)
    {
        ["BIENVENIDO10"] = new DescuentoPorcentaje(10),
        ["FRUVER5"] = new DescuentoPorcentaje(5),
        ["MERCADO20"] = new DescuentoMontoFijo(20_000m, 150_000m)
    };

    public IReadOnlyCollection<string> Codigos => _cupones.Keys;

    public bool Existe(string? codigo) =>
        !string.IsNullOrWhiteSpace(codigo) && _cupones.ContainsKey(codigo.Trim());

    /// <summary>Devuelve el descuento del cupón o <see cref="SinDescuento"/> si no existe.</summary>
    public Descuento Obtener(string? codigo) =>
        Existe(codigo) ? _cupones[codigo!.Trim()] : new SinDescuento();

    public void Registrar(string codigo, Descuento descuento) => _cupones[codigo.Trim()] = descuento;
}
