using Domicilios.Core.Entidades;

namespace Domicilios.Core.Estructuras;

/// <summary>Tarifas de envío por zona (Dictionary de solo lectura: búsqueda O(1) por clave).</summary>
public static class TarifaDomicilio
{
    public const decimal EnvioGratisDesde = 120_000m;

    private static readonly IReadOnlyDictionary<ZonaEntrega, decimal> Tarifas =
        new Dictionary<ZonaEntrega, decimal>
        {
            [ZonaEntrega.Centro] = 4_000m,
            [ZonaEntrega.Norte] = 6_000m,
            [ZonaEntrega.Sur] = 6_000m,
            [ZonaEntrega.Oriente] = 7_000m,
            [ZonaEntrega.Occidente] = 7_000m
        };

    public static decimal TarifaBase(ZonaEntrega zona) => Tarifas[zona];

    public static IEnumerable<KeyValuePair<ZonaEntrega, decimal>> Todas => Tarifas;

    /// <summary>El envío es gratis cuando el valor (ya con descuento) supera el umbral.</summary>
    public static Dinero Calcular(ZonaEntrega zona, Dinero valorCompra) =>
        valorCompra.Valor >= EnvioGratisDesde ? Dinero.Cero : new Dinero(Tarifas[zona]);
}
