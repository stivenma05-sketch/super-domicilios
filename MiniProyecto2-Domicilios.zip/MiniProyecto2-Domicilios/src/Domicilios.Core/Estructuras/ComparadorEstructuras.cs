using System.Diagnostics;

namespace Domicilios.Core.Estructuras;

public record ResultadoComparacion(string Operacion, string Estructura, string Complejidad, double Milisegundos);

/// <summary>
/// Ejemplo comparativo que justifica la elección de estructuras de datos:
/// mide el mismo trabajo con distintas colecciones de .NET.
/// </summary>
public static class ComparadorEstructuras
{
    public static List<ResultadoComparacion> Ejecutar(int elementos = 20_000, int busquedas = 2_000)
    {
        var resultados = new List<ResultadoComparacion>();
        var ids = Enumerable.Range(1, elementos).ToArray();
        var azar = new Random(42);
        var objetivos = Enumerable.Range(0, busquedas).Select(_ => azar.Next(1, elementos + 1)).ToArray();

        // --- 1. Buscar un producto por su id -------------------------------------------------
        var lista = ids.ToList();
        var conjunto = new HashSet<int>(ids);
        var diccionario = ids.ToDictionary(i => i, i => $"Producto {i}");
        var ordenado = new SortedDictionary<int, string>(diccionario);
        var aciertos = 0;

        resultados.Add(Medir("Buscar por id", "List<T>.Contains", "O(n)", () =>
        {
            foreach (var x in objetivos) if (lista.Contains(x)) aciertos++;
        }));
        resultados.Add(Medir("Buscar por id", "HashSet<T>.Contains", "O(1)", () =>
        {
            foreach (var x in objetivos) if (conjunto.Contains(x)) aciertos++;
        }));
        resultados.Add(Medir("Buscar por id", "Dictionary<K,V> (usada en el carrito)", "O(1)", () =>
        {
            foreach (var x in objetivos) if (diccionario.TryGetValue(x, out _)) aciertos++;
        }));
        resultados.Add(Medir("Buscar por id", "SortedDictionary<K,V>", "O(log n)", () =>
        {
            foreach (var x in objetivos) if (ordenado.TryGetValue(x, out _)) aciertos++;
        }));

        // --- 2. Despachar pedidos en orden de llegada (FIFO) -----------------------------------
        var listaPedidos = ids.ToList();
        var colaPedidos = new Queue<int>(ids);
        var suma = 0;

        resultados.Add(Medir("Despachar pedidos FIFO", "List<T>.RemoveAt(0)", "O(n) por extracción", () =>
        {
            while (listaPedidos.Count > 0)
            {
                suma += listaPedidos[0];
                listaPedidos.RemoveAt(0);
            }
        }));
        resultados.Add(Medir("Despachar pedidos FIFO", "Queue<T>.Dequeue (cola de despacho)", "O(1) por extracción", () =>
        {
            while (colaPedidos.Count > 0)
                suma += colaPedidos.Dequeue();
        }));

        // Evita que el compilador considere el trabajo anterior como código muerto.
        if (aciertos < 0 || suma < 0)
            throw new InvalidOperationException("Resultado inesperado.");

        return resultados;
    }

    private static ResultadoComparacion Medir(string operacion, string estructura, string complejidad, Action trabajo)
    {
        var reloj = Stopwatch.StartNew();
        trabajo();
        reloj.Stop();
        return new ResultadoComparacion(operacion, estructura, complejidad, Math.Round(reloj.Elapsed.TotalMilliseconds, 3));
    }
}
