using System.Collections;
using Domicilios.Core.Entidades;

namespace Domicilios.Core.Estructuras;

/// <summary>Línea del carrito. Es una clase simple para poder guardarse en sesión como JSON.</summary>
public class ItemCarrito
{
    public int ProductoId { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Unidad { get; set; } = "und";
    public decimal PrecioUnitario { get; set; }
    public int Cantidad { get; set; }

    public decimal Subtotal => PrecioUnitario * Cantidad;
}

/// <summary>
/// Carrito de compras. Internamente usa un <see cref="Dictionary{TKey,TValue}"/> indexado por
/// id de producto: acceso O(1) y garantiza que un producto aparezca una sola vez.
/// Demuestra: indexador, IEnumerable personalizado con yield, propiedades calculadas.
/// </summary>
public class CarritoCompras : IEnumerable<ItemCarrito>
{
    private readonly Dictionary<int, ItemCarrito> _items = new();

    public CarritoCompras()
    {
    }

    public CarritoCompras(IEnumerable<ItemCarrito> items)
    {
        foreach (var item in items)
            _items[item.ProductoId] = item;
    }

    /// <summary>Indexador: carrito[productoId].</summary>
    public ItemCarrito this[int productoId] => _items[productoId];

    public bool Contiene(int productoId) => _items.ContainsKey(productoId);

    /// <summary>Número de líneas (productos distintos).</summary>
    public int Cantidad => _items.Count;

    public int TotalUnidades => _items.Values.Sum(i => i.Cantidad);

    public Dinero Subtotal => new(_items.Values.Sum(i => i.Subtotal));

    public Resultado Agregar(Producto producto, int cantidad)
    {
        if (cantidad <= 0)
            return Resultado.Fallo("La cantidad debe ser mayor que cero.");
        if (!producto.Activo)
            return Resultado.Fallo($"'{producto.Nombre}' no está disponible.");

        _items.TryGetValue(producto.Id, out var existente);
        var nuevaCantidad = (existente?.Cantidad ?? 0) + cantidad;

        if (nuevaCantidad > producto.Stock)
            return Resultado.Fallo($"Solo hay {producto.Stock} {producto.Unidad} de '{producto.Nombre}'.");

        if (existente is null)
        {
            _items[producto.Id] = new ItemCarrito
            {
                ProductoId = producto.Id,
                Nombre = producto.Nombre,
                Unidad = producto.Unidad,
                PrecioUnitario = producto.Precio,
                Cantidad = cantidad
            };
        }
        else
        {
            existente.Cantidad = nuevaCantidad;
            existente.PrecioUnitario = producto.Precio;
        }

        return Resultado.Ok();
    }

    public bool Quitar(int productoId) => _items.Remove(productoId);

    public void Vaciar() => _items.Clear();

    public IEnumerator<ItemCarrito> GetEnumerator()
    {
        foreach (var item in _items.Values)
            yield return item;
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
