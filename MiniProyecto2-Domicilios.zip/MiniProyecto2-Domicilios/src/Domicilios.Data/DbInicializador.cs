using Domicilios.Core.Entidades;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Domicilios.Data;

/// <summary>Crea la base de datos, los roles y los datos de ejemplo la primera vez que se ejecuta.</summary>
public static class DbInicializador
{
    public static async Task InicializarAsync(IServiceProvider raiz)
    {
        using var alcance = raiz.CreateScope();
        var sp = alcance.ServiceProvider;

        var db = sp.GetRequiredService<AppDbContext>();
        // Si el proyecto ya tiene migraciones (dotnet ef migrations add) se aplican; si no, se crea el esquema.
        if (db.Database.GetMigrations().Any())
            await db.Database.MigrateAsync();
        else
            await db.Database.EnsureCreatedAsync();

        var roles = sp.GetRequiredService<RoleManager<IdentityRole>>();
        foreach (var rol in RolesApp.Todos)
        {
            if (!await roles.RoleExistsAsync(rol))
                await roles.CreateAsync(new IdentityRole(rol));
        }

        var usuarios = sp.GetRequiredService<UserManager<ApplicationUser>>();
        await CrearUsuarioAsync(usuarios, "admin@domicilios.com", "Administrador del Super", "Admin123", RolesApp.Admin);
        await CrearUsuarioAsync(usuarios, "repartidor@domicilios.com", "Carlos Repartidor", "Reparto123", RolesApp.Repartidor);
        await CrearUsuarioAsync(usuarios, "cliente@domicilios.com", "Laura Cliente", "Cliente123", RolesApp.Cliente,
                                "Calle 10 # 5-20, Centro");

        if (!await db.Categorias.AnyAsync())
            await SembrarCatalogoAsync(db);
    }

    private static async Task CrearUsuarioAsync(UserManager<ApplicationUser> usuarios, string correo, string nombre,
                                                string clave, string rol, string? direccion = null)
    {
        if (await usuarios.FindByEmailAsync(correo) is not null)
            return;

        var usuario = new ApplicationUser
        {
            UserName = correo,
            Email = correo,
            EmailConfirmed = true,
            NombreCompleto = nombre,
            DireccionPredeterminada = direccion
        };

        var resultado = await usuarios.CreateAsync(usuario, clave);
        if (!resultado.Succeeded)
            throw new InvalidOperationException(
                "No se pudo crear el usuario de ejemplo: " + string.Join("; ", resultado.Errors.Select(e => e.Description)));

        await usuarios.AddToRoleAsync(usuario, rol);
    }

    private static async Task SembrarCatalogoAsync(AppDbContext db)
    {
        var frutas = new Categoria { Nombre = "Frutas y verduras", Icono = "🥦" };
        var lacteos = new Categoria { Nombre = "Lácteos y huevos", Icono = "🥛" };
        var carnes = new Categoria { Nombre = "Carnes", Icono = "🥩" };
        var despensa = new Categoria { Nombre = "Despensa", Icono = "🍚" };
        var bebidas = new Categoria { Nombre = "Bebidas", Icono = "🥤" };
        var aseo = new Categoria { Nombre = "Aseo y hogar", Icono = "🧼" };

        db.Categorias.AddRange(frutas, lacteos, carnes, despensa, bebidas, aseo);

        db.Productos.AddRange(
            new Producto { Nombre = "Banano", Precio = 3_200, Stock = 120, Unidad = "kg", Categoria = frutas, Descripcion = "Banano criollo maduro." },
            new Producto { Nombre = "Tomate chonto", Precio = 4_500, Stock = 80, Unidad = "kg", Categoria = frutas },
            new Producto { Nombre = "Cebolla cabezona", Precio = 3_800, Stock = 90, Unidad = "kg", Categoria = frutas },
            new Producto { Nombre = "Aguacate Hass", Precio = 6_900, Stock = 60, Unidad = "und", Categoria = frutas },
            new Producto { Nombre = "Leche entera 1L", Precio = 4_300, Stock = 150, Unidad = "und", Categoria = lacteos },
            new Producto { Nombre = "Huevos AA x30", Precio = 19_500, Stock = 40, Unidad = "und", Categoria = lacteos },
            new Producto { Nombre = "Queso campesino 500g", Precio = 12_800, Stock = 35, Unidad = "und", Categoria = lacteos },
            new Producto { Nombre = "Pechuga de pollo", Precio = 14_900, Stock = 50, Unidad = "kg", Categoria = carnes },
            new Producto { Nombre = "Carne molida de res", Precio = 21_000, Stock = 45, Unidad = "kg", Categoria = carnes },
            new Producto { Nombre = "Arroz 5 lb", Precio = 17_900, Stock = 100, Unidad = "und", Categoria = despensa },
            new Producto { Nombre = "Aceite vegetal 1L", Precio = 13_400, Stock = 70, Unidad = "und", Categoria = despensa },
            new Producto { Nombre = "Pasta espagueti 500g", Precio = 4_200, Stock = 110, Unidad = "und", Categoria = despensa },
            new Producto { Nombre = "Café molido 500g", Precio = 22_900, Stock = 55, Unidad = "und", Categoria = despensa },
            new Producto { Nombre = "Gaseosa 1.5L", Precio = 6_500, Stock = 90, Unidad = "und", Categoria = bebidas },
            new Producto { Nombre = "Jugo de naranja 1L", Precio = 7_800, Stock = 60, Unidad = "und", Categoria = bebidas },
            new Producto { Nombre = "Agua 600ml x6", Precio = 9_000, Stock = 75, Unidad = "und", Categoria = bebidas },
            new Producto { Nombre = "Detergente líquido 2L", Precio = 24_500, Stock = 40, Unidad = "und", Categoria = aseo },
            new Producto { Nombre = "Papel higiénico x12", Precio = 21_900, Stock = 65, Unidad = "und", Categoria = aseo },
            new Producto { Nombre = "Jabón de manos 500ml", Precio = 8_900, Stock = 50, Unidad = "und", Categoria = aseo });

        await db.SaveChangesAsync();
    }
}
