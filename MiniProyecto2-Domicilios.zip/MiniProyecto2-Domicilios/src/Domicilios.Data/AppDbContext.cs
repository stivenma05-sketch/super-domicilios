using Domicilios.Core.Entidades;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Domicilios.Data;

/// <summary>Contexto único: tablas de Identity + tablas del dominio.</summary>
public class AppDbContext : IdentityDbContext<ApplicationUser>
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Categoria> Categorias => Set<Categoria>();
    public DbSet<Producto> Productos => Set<Producto>();
    public DbSet<Pedido> Pedidos => Set<Pedido>();
    public DbSet<PedidoItem> PedidoItems => Set<PedidoItem>();
    public DbSet<CambioEstado> CambiosEstado => Set<CambioEstado>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Categoria>(e =>
        {
            e.HasIndex(c => c.Nombre).IsUnique();
            e.HasMany(c => c.Productos)
             .WithOne(p => p.Categoria)
             .HasForeignKey(p => p.CategoriaId)
             .OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<Producto>(e =>
        {
            e.Property(p => p.Precio).HasPrecision(18, 2);
            e.HasIndex(p => p.Nombre);
        });

        builder.Entity<Pedido>(e =>
        {
            e.Property(p => p.Subtotal).HasPrecision(18, 2);
            e.Property(p => p.Descuento).HasPrecision(18, 2);
            e.Property(p => p.CostoDomicilio).HasPrecision(18, 2);
            e.Property(p => p.Total).HasPrecision(18, 2);
            e.Property(p => p.Estado).HasConversion<string>().HasMaxLength(20);
            e.Property(p => p.Zona).HasConversion<string>().HasMaxLength(20);
            e.HasIndex(p => p.ClienteId);
            e.HasIndex(p => p.Estado);

            e.HasMany(p => p.Items).WithOne().HasForeignKey(i => i.PedidoId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(p => p.Historial).WithOne().HasForeignKey(h => h.PedidoId).OnDelete(DeleteBehavior.Cascade);
        });

        builder.Entity<PedidoItem>(e => e.Property(i => i.PrecioUnitario).HasPrecision(18, 2));

        builder.Entity<CambioEstado>(e => e.Property(c => c.Estado).HasConversion<string>().HasMaxLength(20));
    }
}
