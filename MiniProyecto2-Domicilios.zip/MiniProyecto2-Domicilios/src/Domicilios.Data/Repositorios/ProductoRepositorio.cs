using Domicilios.Core.Contratos;
using Domicilios.Core.Entidades;
using Microsoft.EntityFrameworkCore;

namespace Domicilios.Data.Repositorios;

public class ProductoRepositorio : IProductoRepositorio
{
    private readonly AppDbContext _db;

    public ProductoRepositorio(AppDbContext db) => _db = db;

    public async Task<List<Producto>> ListarAsync(int? categoriaId = null, string? busqueda = null, bool soloActivos = true)
    {
        IQueryable<Producto> consulta = _db.Productos.Include(p => p.Categoria);

        if (soloActivos)
            consulta = consulta.Where(p => p.Activo);
        if (categoriaId.HasValue)
            consulta = consulta.Where(p => p.CategoriaId == categoriaId.Value);
        if (!string.IsNullOrWhiteSpace(busqueda))
        {
            var texto = busqueda.Trim().ToLower();
            consulta = consulta.Where(p => p.Nombre.ToLower().Contains(texto));
        }

        return await consulta.OrderBy(p => p.Nombre).ToListAsync();
    }

    public Task<Producto?> ObtenerAsync(int id) =>
        _db.Productos.Include(p => p.Categoria).FirstOrDefaultAsync(p => p.Id == id);

    public Task<List<Categoria>> ListarCategoriasAsync() =>
        _db.Categorias.OrderBy(c => c.Nombre).ToListAsync();

    public async Task AgregarAsync(Producto producto) => await _db.Productos.AddAsync(producto);

    public Task ActualizarAsync(Producto producto)
    {
        _db.Productos.Update(producto);
        return Task.CompletedTask;
    }
}
