using Domicilios.Core.Contratos;

namespace Domicilios.Data.Repositorios;

public class UnidadDeTrabajo : IUnidadDeTrabajo
{
    private readonly AppDbContext _db;

    public UnidadDeTrabajo(AppDbContext db) => _db = db;

    public Task<int> GuardarCambiosAsync() => _db.SaveChangesAsync();
}
