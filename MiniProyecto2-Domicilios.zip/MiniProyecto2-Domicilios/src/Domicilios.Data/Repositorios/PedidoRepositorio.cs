using Domicilios.Core.Contratos;
using Domicilios.Core.Entidades;
using Microsoft.EntityFrameworkCore;

namespace Domicilios.Data.Repositorios;

public class PedidoRepositorio : IPedidoRepositorio
{
    private readonly AppDbContext _db;

    public PedidoRepositorio(AppDbContext db) => _db = db;

    public Task<Pedido?> ObtenerAsync(int id) =>
        _db.Pedidos
           .Include(p => p.Items)
           .Include(p => p.Historial)
           .FirstOrDefaultAsync(p => p.Id == id);

    public async Task<List<Pedido>> ListarAsync(string? clienteId = null, string? repartidorId = null, EstadoPedido? estado = null)
    {
        IQueryable<Pedido> consulta = _db.Pedidos.Include(p => p.Items);

        if (clienteId is not null)
            consulta = consulta.Where(p => p.ClienteId == clienteId);
        if (repartidorId is not null)
            consulta = consulta.Where(p => p.RepartidorId == repartidorId);
        if (estado.HasValue)
            consulta = consulta.Where(p => p.Estado == estado.Value);

        var lista = await consulta.ToListAsync();
        // Se ordena en memoria: más recientes primero.
        return lista.OrderByDescending(p => p.FechaCreacion).ToList();
    }

    public async Task AgregarAsync(Pedido pedido) => await _db.Pedidos.AddAsync(pedido);
}
