using Microsoft.AspNetCore.Identity;

namespace Domicilios.Data;

/// <summary>Configuración compartida por la aplicación web y la de escritorio.</summary>
public static class ConfiguracionBD
{
    /// <summary>
    /// Ruta del archivo SQLite. Por defecto está en la carpeta de datos del usuario, de modo que
    /// la web y el escritorio trabajan sobre la MISMA base de datos. Se puede cambiar con la
    /// variable de entorno DOMICILIOS_DB.
    /// </summary>
    public static string RutaArchivo()
    {
        var personalizada = Environment.GetEnvironmentVariable("DOMICILIOS_DB");
        if (!string.IsNullOrWhiteSpace(personalizada))
            return personalizada;

        var carpeta = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Domicilios");
        Directory.CreateDirectory(carpeta);
        return Path.Combine(carpeta, "domicilios.db");
    }

    public static string CadenaPorDefecto() => $"Data Source={RutaArchivo()}";

    /// <summary>Reglas de contraseña (las mismas en web y escritorio).</summary>
    public static void ConfigurarIdentity(IdentityOptions opciones)
    {
        opciones.Password.RequiredLength = 6;
        opciones.Password.RequireDigit = true;
        opciones.Password.RequireLowercase = false;
        opciones.Password.RequireUppercase = false;
        opciones.Password.RequireNonAlphanumeric = false;
        opciones.User.RequireUniqueEmail = true;
    }
}
