using Microsoft.AspNetCore.Identity;

namespace Domicilios.Data;

/// <summary>Usuario de la aplicación (clientes, repartidores y administradores).</summary>
public class ApplicationUser : IdentityUser
{
    public string NombreCompleto { get; set; } = string.Empty;
    public string? DireccionPredeterminada { get; set; }
}
