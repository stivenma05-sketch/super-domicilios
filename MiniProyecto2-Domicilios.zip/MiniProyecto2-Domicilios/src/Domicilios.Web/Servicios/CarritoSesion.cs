using System.Text.Json;
using Domicilios.Core.Estructuras;

namespace Domicilios.Web.Servicios;

/// <summary>Extensiones para guardar y leer el carrito de compras en la sesión (como JSON).</summary>
public static class CarritoSesion
{
    private const string Clave = "carrito";

    public static CarritoCompras ObtenerCarrito(this ISession sesion)
    {
        var json = sesion.GetString(Clave);
        var items = string.IsNullOrEmpty(json)
            ? new List<ItemCarrito>()
            : JsonSerializer.Deserialize<List<ItemCarrito>>(json) ?? new List<ItemCarrito>();
        return new CarritoCompras(items);
    }

    public static void GuardarCarrito(this ISession sesion, CarritoCompras carrito) =>
        sesion.SetString(Clave, JsonSerializer.Serialize(carrito.ToList()));
}
