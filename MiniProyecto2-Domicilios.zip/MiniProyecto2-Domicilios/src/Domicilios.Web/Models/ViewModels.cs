using System.ComponentModel.DataAnnotations;
using Domicilios.Core.Entidades;
using Domicilios.Core.Servicios;

namespace Domicilios.Web.Models;

public class LoginViewModel
{
    [Required(ErrorMessage = "El correo es obligatorio"), EmailAddress(ErrorMessage = "Correo no válido")]
    [Display(Name = "Correo electrónico")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "La contraseña es obligatoria"), DataType(DataType.Password)]
    [Display(Name = "Contraseña")]
    public string Password { get; set; } = string.Empty;

    [Display(Name = "Recordarme")]
    public bool Recordarme { get; set; }
}

public class RegisterViewModel
{
    [Required(ErrorMessage = "El nombre es obligatorio"), StringLength(120)]
    [Display(Name = "Nombre completo")]
    public string NombreCompleto { get; set; } = string.Empty;

    [Required(ErrorMessage = "El correo es obligatorio"), EmailAddress(ErrorMessage = "Correo no válido")]
    [Display(Name = "Correo electrónico")]
    public string Email { get; set; } = string.Empty;

    [Display(Name = "Dirección predeterminada"), StringLength(200)]
    public string? Direccion { get; set; }

    [Required(ErrorMessage = "La contraseña es obligatoria"), DataType(DataType.Password)]
    [StringLength(100, MinimumLength = 6, ErrorMessage = "Mínimo 6 caracteres")]
    [Display(Name = "Contraseña")]
    public string Password { get; set; } = string.Empty;

    [DataType(DataType.Password), Compare(nameof(Password), ErrorMessage = "Las contraseñas no coinciden")]
    [Display(Name = "Confirmar contraseña")]
    public string ConfirmarPassword { get; set; } = string.Empty;
}

public class CatalogoViewModel
{
    public List<Producto> Productos { get; set; } = new();
    public List<Categoria> Categorias { get; set; } = new();
    public int? CategoriaId { get; set; }
    public string? Busqueda { get; set; }
}

public class ConfirmarPedidoViewModel
{
    [Required(ErrorMessage = "La dirección es obligatoria"), StringLength(200)]
    [Display(Name = "Dirección de entrega")]
    public string Direccion { get; set; } = string.Empty;

    [Display(Name = "Zona de entrega")]
    public ZonaEntrega Zona { get; set; } = ZonaEntrega.Centro;

    [Display(Name = "Cupón (opcional)"), StringLength(30)]
    public string? Cupon { get; set; }

    public ResumenPedido? Resumen { get; set; }
}

public class PedidosIndexViewModel
{
    public List<Pedido> Pedidos { get; set; } = new();
    public List<Pedido> Disponibles { get; set; } = new();
    public EstadoPedido? Filtro { get; set; }
}

public class ReporteViewModel
{
    public ResumenVentas Resumen { get; set; } = new(0, 0, 0, 0, 0);
    public List<VentaZona> PorZona { get; set; } = new();
    public List<ProductoVendido> TopProductos { get; set; } = new();
    public List<VentaDia> PorDia { get; set; } = new();
}
