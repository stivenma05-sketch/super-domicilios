using Domicilios.Core.Contratos;
using Domicilios.Core.Estructuras;
using Domicilios.Core.Servicios;
using Domicilios.Data;
using Domicilios.Data.Repositorios;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// --- Base de datos (EF Core + SQLite) ---
var cadenaConexion = builder.Configuration.GetConnectionString("Default") ?? ConfiguracionBD.CadenaPorDefecto();
builder.Services.AddDbContext<AppDbContext>(opciones => opciones.UseSqlite(cadenaConexion));

// --- Autenticación y roles (ASP.NET Core Identity) ---
builder.Services
    .AddIdentity<ApplicationUser, IdentityRole>(ConfiguracionBD.ConfigurarIdentity)
    .AddEntityFrameworkStores<AppDbContext>()
    .AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(opciones =>
{
    opciones.LoginPath = "/Account/Login";
    opciones.AccessDeniedPath = "/Account/AccesoDenegado";
});

// --- Servicios de la aplicación (inyección de dependencias) ---
builder.Services.AddScoped<IProductoRepositorio, ProductoRepositorio>();
builder.Services.AddScoped<IPedidoRepositorio, PedidoRepositorio>();
builder.Services.AddScoped<IUnidadDeTrabajo, UnidadDeTrabajo>();
builder.Services.AddSingleton<CatalogoCupones>();
builder.Services.AddScoped<PedidoService>();

// El carrito de compras vive en la sesión del usuario.
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(opciones =>
{
    opciones.IdleTimeout = TimeSpan.FromHours(2);
    opciones.Cookie.HttpOnly = true;
    opciones.Cookie.IsEssential = true;
});

builder.Services.AddControllersWithViews();

var app = builder.Build();

await DbInicializador.InicializarAsync(app.Services);

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
