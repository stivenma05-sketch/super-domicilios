using Domicilios.Core;
using Domicilios.Core.Entidades;
using Domicilios.Core.Servicios;
using Domicilios.Data;
using Domicilios.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Domicilios.Web.Controllers;

[Authorize]
public class PedidosController : Controller
{
    private readonly PedidoService _pedidos;
    private readonly UserManager<ApplicationUser> _usuarios;

    public PedidosController(PedidoService pedidos, UserManager<ApplicationUser> usuarios)
    {
        _pedidos = pedidos;
        _usuarios = usuarios;
    }

    public async Task<IActionResult> Index(EstadoPedido? estado)
    {
        var usuario = await _usuarios.GetUserAsync(User);
        if (usuario is null)
            return Challenge();

        var modelo = new PedidosIndexViewModel { Filtro = estado };

        if (User.IsInRole(RolesApp.Admin))
        {
            modelo.Pedidos = await _pedidos.ListarAsync(estado: estado);
        }
        else if (User.IsInRole(RolesApp.Repartidor))
        {
            modelo.Pedidos = await _pedidos.ListarAsync(repartidorId: usuario.Id, estado: estado);
            var enPreparacion = await _pedidos.ListarAsync(estado: EstadoPedido.EnPreparacion);
            modelo.Disponibles = enPreparacion.Where(p => p.RepartidorId is null).ToList();
        }
        else
        {
            modelo.Pedidos = await _pedidos.ListarAsync(clienteId: usuario.Id, estado: estado);
        }

        return View(modelo);
    }

    public async Task<IActionResult> Detalle(int id)
    {
        var pedido = await _pedidos.ObtenerAsync(id);
        if (pedido is null)
            return NotFound();

        var usuario = await _usuarios.GetUserAsync(User);
        if (usuario is null || !PuedeVer(pedido, usuario.Id))
            return Forbid();

        ViewBag.UsuarioId = usuario.Id;
        return View(pedido);
    }

    // ---- Acciones de cambio de estado -------------------------------------------------------

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = RolesApp.Admin)]
    public async Task<IActionResult> Preparar(int id) =>
        await CambiarAsync(id, EstadoPedido.EnPreparacion);

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = RolesApp.Repartidor)]
    public async Task<IActionResult> Tomar(int id)
    {
        var usuario = await _usuarios.GetUserAsync(User);
        if (usuario is null)
            return Challenge();

        var resultado = await _pedidos.TomarPedidoAsync(id, usuario.Id, usuario.NombreCompleto);
        Notificar(resultado, "Pedido tomado: ¡a repartir!");
        return RedirectToAction(nameof(Detalle), new { id });
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = RolesApp.Repartidor + "," + RolesApp.Admin)]
    public async Task<IActionResult> Entregar(int id)
    {
        var pedido = await _pedidos.ObtenerAsync(id);
        if (pedido is null)
            return NotFound();

        var usuario = await _usuarios.GetUserAsync(User);
        if (usuario is null)
            return Challenge();

        // Un repartidor solo puede entregar sus propios pedidos.
        if (!User.IsInRole(RolesApp.Admin) && pedido.RepartidorId != usuario.Id)
            return Forbid();

        return await CambiarAsync(id, EstadoPedido.Entregado, usuario.NombreCompleto);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancelar(int id)
    {
        var pedido = await _pedidos.ObtenerAsync(id);
        if (pedido is null)
            return NotFound();

        var usuario = await _usuarios.GetUserAsync(User);
        if (usuario is null)
            return Challenge();

        var esAdmin = User.IsInRole(RolesApp.Admin);
        var esDueno = pedido.ClienteId == usuario.Id && pedido.Estado == EstadoPedido.Pendiente;
        if (!esAdmin && !esDueno)
            return Forbid();

        return await CambiarAsync(id, EstadoPedido.Cancelado, usuario.NombreCompleto);
    }

    [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = RolesApp.Admin)]
    public async Task<IActionResult> Deshacer(int id)
    {
        var resultado = await _pedidos.DeshacerUltimoCambioAsync(id);
        Notificar(resultado, "Se revirtió el último cambio de estado.");
        return RedirectToAction(nameof(Detalle), new { id });
    }

    // ---- Auxiliares --------------------------------------------------------------------------

    private async Task<IActionResult> CambiarAsync(int id, EstadoPedido nuevo, string? nombre = null)
    {
        if (nombre is null)
        {
            var usuario = await _usuarios.GetUserAsync(User);
            nombre = usuario?.NombreCompleto ?? "Sistema";
        }

        var resultado = await _pedidos.CambiarEstadoAsync(id, nuevo, nombre);
        Notificar(resultado, $"El pedido #{id} ahora está '{nuevo.Descripcion()}'.");
        return RedirectToAction(nameof(Detalle), new { id });
    }

    private void Notificar(Resultado resultado, string mensajeExito)
    {
        if (resultado.Exito)
            TempData["Mensaje"] = mensajeExito;
        else
            TempData["Error"] = resultado.Error;
    }

    private bool PuedeVer(Pedido pedido, string usuarioId)
    {
        if (User.IsInRole(RolesApp.Admin))
            return true;
        if (User.IsInRole(RolesApp.Repartidor))
            return pedido.RepartidorId == usuarioId
                   || (pedido.Estado == EstadoPedido.EnPreparacion && pedido.RepartidorId is null);
        return pedido.ClienteId == usuarioId;
    }
}
