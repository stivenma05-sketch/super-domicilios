using System.Security.Claims;
using Domicilios.Core.Contratos;
using Domicilios.Core.Estructuras;
using Domicilios.Core.Entidades;
using Domicilios.Core.Servicios;
using Domicilios.Data;
using Domicilios.Web.Models;
using Domicilios.Web.Servicios;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Domicilios.Web.Controllers;

[Authorize(Roles = RolesApp.Cliente)]
public class CarritoController : Controller
{
    private readonly IProductoRepositorio _productos;
    private readonly PedidoService _pedidos;
    private readonly UserManager<ApplicationUser> _usuarios;

    public CarritoController(IProductoRepositorio productos, PedidoService pedidos, UserManager<ApplicationUser> usuarios)
    {
        _productos = productos;
        _pedidos = pedidos;
        _usuarios = usuarios;
    }

    public IActionResult Index() => View(HttpContext.Session.ObtenerCarrito());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Agregar(int id, int cantidad = 1, string? returnUrl = null)
    {
        var producto = await _productos.ObtenerAsync(id);
        if (producto is null)
            return NotFound();

        var carrito = HttpContext.Session.ObtenerCarrito();
        var resultado = carrito.Agregar(producto, cantidad);

        if (resultado.Exito)
        {
            HttpContext.Session.GuardarCarrito(carrito);
            TempData["Mensaje"] = $"'{producto.Nombre}' se agregó al carrito.";
        }
        else
        {
            TempData["Error"] = resultado.Error;
        }

        return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? Redirect(returnUrl)
            : RedirectToAction("Index", "Catalogo");
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Quitar(int id)
    {
        var carrito = HttpContext.Session.ObtenerCarrito();
        carrito.Quitar(id);
        HttpContext.Session.GuardarCarrito(carrito);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Vaciar()
    {
        HttpContext.Session.GuardarCarrito(new CarritoCompras());
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Confirmar()
    {
        var carrito = HttpContext.Session.ObtenerCarrito();
        if (carrito.Cantidad == 0)
            return RedirectToAction(nameof(Index));

        var usuario = await _usuarios.GetUserAsync(User);
        var modelo = new ConfirmarPedidoViewModel
        {
            Direccion = usuario?.DireccionPredeterminada ?? string.Empty,
            Resumen = _pedidos.Previsualizar(carrito, ZonaEntrega.Centro, null)
        };
        ViewBag.Carrito = carrito;
        return View(modelo);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Confirmar(ConfirmarPedidoViewModel modelo, bool calcular = false)
    {
        var carrito = HttpContext.Session.ObtenerCarrito();
        if (carrito.Cantidad == 0)
            return RedirectToAction(nameof(Index));

        ViewBag.Carrito = carrito;
        modelo.Resumen = _pedidos.Previsualizar(carrito, modelo.Zona, modelo.Cupon);

        // El botón "Calcular total" solo muestra el desglose, sin crear el pedido.
        if (calcular || !ModelState.IsValid)
            return View(modelo);

        var usuario = await _usuarios.GetUserAsync(User);
        if (usuario is null)
            return Challenge();

        var resultado = await _pedidos.CrearPedidoAsync(
            usuario.Id, usuario.NombreCompleto, carrito, modelo.Direccion, modelo.Zona, modelo.Cupon);

        if (!resultado.Exito || resultado.Valor is null)
        {
            ModelState.AddModelError(string.Empty, resultado.Error ?? "No se pudo crear el pedido.");
            return View(modelo);
        }

        HttpContext.Session.GuardarCarrito(new CarritoCompras());
        TempData["Mensaje"] = $"¡Pedido #{resultado.Valor.Id} creado con éxito!";
        return RedirectToAction("Detalle", "Pedidos", new { id = resultado.Valor.Id });
    }
}
