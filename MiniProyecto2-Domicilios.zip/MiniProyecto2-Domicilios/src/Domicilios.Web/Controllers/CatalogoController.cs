using Domicilios.Core.Contratos;
using Domicilios.Web.Models;
using Microsoft.AspNetCore.Mvc;

namespace Domicilios.Web.Controllers;

public class CatalogoController : Controller
{
    private readonly IProductoRepositorio _productos;

    public CatalogoController(IProductoRepositorio productos) => _productos = productos;

    public async Task<IActionResult> Index(int? categoriaId, string? busqueda)
    {
        var modelo = new CatalogoViewModel
        {
            CategoriaId = categoriaId,
            Busqueda = busqueda,
            Categorias = await _productos.ListarCategoriasAsync(),
            Productos = await _productos.ListarAsync(categoriaId, busqueda)
        };
        return View(modelo);
    }
}
