using Domicilios.Core.Entidades;
using Domicilios.Data;
using Domicilios.Web.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Domicilios.Web.Controllers;

public class AccountController : Controller
{
    private readonly UserManager<ApplicationUser> _usuarios;
    private readonly SignInManager<ApplicationUser> _sesion;

    public AccountController(UserManager<ApplicationUser> usuarios, SignInManager<ApplicationUser> sesion)
    {
        _usuarios = usuarios;
        _sesion = sesion;
    }

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        ViewData["ReturnUrl"] = returnUrl;
        return View(new LoginViewModel());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel modelo, string? returnUrl = null)
    {
        ViewData["ReturnUrl"] = returnUrl;
        if (!ModelState.IsValid)
            return View(modelo);

        var resultado = await _sesion.PasswordSignInAsync(modelo.Email, modelo.Password, modelo.Recordarme, lockoutOnFailure: false);
        if (resultado.Succeeded)
            return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
                ? Redirect(returnUrl)
                : RedirectToAction("Index", "Home");

        ModelState.AddModelError(string.Empty, "Correo o contraseña incorrectos.");
        return View(modelo);
    }

    [HttpGet]
    public IActionResult Register() => View(new RegisterViewModel());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel modelo)
    {
        if (!ModelState.IsValid)
            return View(modelo);

        var usuario = new ApplicationUser
        {
            UserName = modelo.Email,
            Email = modelo.Email,
            EmailConfirmed = true,
            NombreCompleto = modelo.NombreCompleto,
            DireccionPredeterminada = modelo.Direccion
        };

        var resultado = await _usuarios.CreateAsync(usuario, modelo.Password);
        if (!resultado.Succeeded)
        {
            foreach (var error in resultado.Errors)
                ModelState.AddModelError(string.Empty, error.Description);
            return View(modelo);
        }

        // Todo usuario que se registra desde la web es Cliente. Admin y Repartidor los crea el administrador.
        await _usuarios.AddToRoleAsync(usuario, RolesApp.Cliente);
        await _sesion.SignInAsync(usuario, isPersistent: false);
        return RedirectToAction("Index", "Catalogo");
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await _sesion.SignOutAsync();
        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Home");
    }

    public IActionResult AccesoDenegado() => View();
}
