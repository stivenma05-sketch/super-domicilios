using Domicilios.Core.Entidades;
using Domicilios.Core.Estructuras;
using Domicilios.Core.Servicios;
using Domicilios.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Domicilios.Web.Controllers;

[Authorize(Roles = RolesApp.Admin)]
public class ReportesController : Controller
{
    private readonly PedidoService _pedidos;

    public ReportesController(PedidoService pedidos) => _pedidos = pedidos;

    public async Task<IActionResult> Index()
    {
        var pedidos = await _pedidos.ListarAsync();
        var modelo = new ReporteViewModel
        {
            Resumen = ReporteService.Resumen(pedidos),
            PorZona = ReporteService.VentasPorZona(pedidos).Values.ToList(),
            TopProductos = ReporteService.TopProductos(pedidos, 5),
            PorDia = ReporteService.VentasPorDia(pedidos)
        };
        return View(modelo);
    }

    /// <summary>Comparativa de rendimiento de estructuras de datos (justificación para la sustentación).</summary>
    public IActionResult Estructuras() => View(ComparadorEstructuras.Ejecutar());
}
