using Domicilios.Core.Contratos;
using Domicilios.Core.Entidades;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Domicilios.Web.Controllers;

/// <summary>Administración del catálogo (solo rol Admin).</summary>
[Authorize(Roles = RolesApp.Admin)]
public class ProductosController : Controller
{
    private readonly IProductoRepositorio _productos;
    private readonly IUnidadDeTrabajo _unidad;

    public ProductosController(IProductoRepositorio productos, IUnidadDeTrabajo unidad)
    {
        _productos = productos;
        _unidad = unidad;
    }

    public async Task<IActionResult> Index() =>
        View(await _productos.ListarAsync(soloActivos: false));

    [HttpGet]
    public async Task<IActionResult> Crear()
    {
        await CargarCategoriasAsync();
        return View("Form", new Producto());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Crear([Bind("Nombre,Descripcion,Precio,Stock,Unidad,CategoriaId")] Producto producto)
    {
        ModelState.Remove(nameof(Producto.Categoria));
        if (!ModelState.IsValid)
        {
            await CargarCategoriasAsync(producto.CategoriaId);
            return View("Form", producto);
        }

        producto.Activo = true;
        await _productos.AgregarAsync(producto);
        await _unidad.GuardarCambiosAsync();
        TempData["Mensaje"] = "Producto creado.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Editar(int id)
    {
        var producto = await _productos.ObtenerAsync(id);
        if (producto is null)
            return NotFound();

        await CargarCategoriasAsync(producto.CategoriaId);
        return View("Form", producto);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Editar(int id, [Bind("Id,Nombre,Descripcion,Precio,Stock,Unidad,CategoriaId,Activo")] Producto datos)
    {
        ModelState.Remove(nameof(Producto.Categoria));
        if (id != datos.Id)
            return BadRequest();

        if (!ModelState.IsValid)
        {
            await CargarCategoriasAsync(datos.CategoriaId);
            return View("Form", datos);
        }

        var producto = await _productos.ObtenerAsync(id);
        if (producto is null)
            return NotFound();

        producto.Nombre = datos.Nombre;
        producto.Descripcion = datos.Descripcion;
        producto.Precio = datos.Precio;
        producto.Stock = datos.Stock;
        producto.Unidad = datos.Unidad;
        producto.CategoriaId = datos.CategoriaId;
        producto.Activo = datos.Activo;

        await _unidad.GuardarCambiosAsync();
        TempData["Mensaje"] = "Producto actualizado.";
        return RedirectToAction(nameof(Index));
    }

    /// <summary>Borrado lógico: el producto se oculta pero se conserva en los pedidos históricos.</summary>
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> CambiarEstado(int id)
    {
        var producto = await _productos.ObtenerAsync(id);
        if (producto is null)
            return NotFound();

        producto.Activo = !producto.Activo;
        await _unidad.GuardarCambiosAsync();
        TempData["Mensaje"] = producto.Activo ? "Producto activado." : "Producto desactivado.";
        return RedirectToAction(nameof(Index));
    }

    private async Task CargarCategoriasAsync(int? seleccionada = null)
    {
        var categorias = await _productos.ListarCategoriasAsync();
        ViewBag.Categorias = new SelectList(categorias, nameof(Categoria.Id), nameof(Categoria.Nombre), seleccionada);
    }
}
